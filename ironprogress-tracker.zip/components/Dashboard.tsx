import React, { useEffect, useState } from 'react';
import { User, WorkoutPlan, WorkoutSessionLog, BodyMeasurements, AppView } from '../types';
import { storage } from '../services/storage';
import { 
  Activity, 
  Camera, 
  TrendingUp, 
  ChevronLeft, 
  ChevronRight,
  Dumbbell,
  Footprints,
  HeartPulse,
  ArrowUpFromLine,
  ArrowDownToLine,
  PlayCircle,
  CheckCircle2,
  Plus,
  Settings as SettingsIcon
} from 'lucide-react';

interface Props {
  user: User;
  onChangeView: (view: AppView) => void;
  onStartPlan: (plan: WorkoutPlan) => void;
}

export const Dashboard: React.FC<Props> = ({ user, onChangeView, onStartPlan }) => {
  const [plans, setPlans] = useState<WorkoutPlan[]>([]);
  const [nextPlanId, setNextPlanId] = useState<string | null>(null);
  const [lastMeasurement, setLastMeasurement] = useState<BodyMeasurements | null>(null);
  const [photoReminder, setPhotoReminder] = useState(false);
  const [allSessions, setAllSessions] = useState<WorkoutSessionLog[]>([]);
  
  // Calendar State
  const [currentDate, setCurrentDate] = useState(new Date());

  useEffect(() => {
    const loadedPlans = storage.getPlans();
    const sessions = storage.getSessions();
    const measurements = storage.getMeasurements();

    setPlans(loadedPlans);
    setAllSessions(sessions);

    // Logic to determine next plan (simple rotation A->B->C->D)
    if (loadedPlans.length > 0) {
      if (sessions.length === 0) {
        setNextPlanId(loadedPlans[0].id);
      } else {
        const lastSession = sessions[sessions.length - 1];
        const lastPlanIndex = loadedPlans.findIndex(p => p.id === lastSession.planId);
        // If plan was deleted, start at 0, else next index
        const nextIndex = lastPlanIndex === -1 ? 0 : (lastPlanIndex + 1) % loadedPlans.length;
        setNextPlanId(loadedPlans[nextIndex].id);
      }
    }

    if (measurements.length > 0) {
      setLastMeasurement(measurements[measurements.length - 1]);
    }

    // Check if today is Sunday and no photo taken this week
    const today = new Date();
    if (today.getDay() === 0) { // 0 = Sunday
        setPhotoReminder(true);
    }
  }, []);

  // --- Calendar Helpers ---

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    // 0 = Sunday, 1 = Monday, ...
    // We want Monday to be 0 for our grid
    const day = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    return day === 0 ? 6 : day - 1; 
  };

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const getWorkoutIcon = (planName: string, className: string = "w-6 h-6") => {
    const lower = planName.toLowerCase();
    // Colors are handled by parent container now (text-current)
    if (lower.includes('bein') || lower.includes('leg') || lower.includes('waden')) {
      return <Footprints className={className} />;
    }
    if (lower.includes('push') || lower.includes('brust') || lower.includes('schulter') || lower.includes('trizeps')) {
      return <ArrowUpFromLine className={className} />;
    }
    if (lower.includes('pull') || lower.includes('rücken') || lower.includes('back') || lower.includes('bizeps')) {
      return <ArrowDownToLine className={className} />;
    }
    if (lower.includes('cardio') || lower.includes('lauf')) {
      return <HeartPulse className={className} />;
    }
    return <Dumbbell className={className} />;
  };

  // Generate Calendar Grid
  const renderCalendarDays = () => {
    const daysInMonth = getDaysInMonth(currentDate);
    const firstDay = getFirstDayOfMonth(currentDate);
    const days = [];

    // Empty cells for days before the 1st
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-14 sm:h-16 bg-transparent"></div>);
    }

    // Day cells
    for (let day = 1; day <= daysInMonth; day++) {
      // Find workouts for this specific day
      const dateToCheck = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
      
      const workoutsOnDay = allSessions.filter(s => {
        const sDate = new Date(s.date);
        return sDate.getDate() === day && 
               sDate.getMonth() === currentDate.getMonth() && 
               sDate.getFullYear() === currentDate.getFullYear();
      });

      const isToday = new Date().toDateString() === dateToCheck.toDateString();

      days.push(
        <div key={day} className={`h-14 sm:h-16 border-t border-slate-200 dark:border-slate-700/50 flex flex-col items-center justify-start pt-1 sm:pt-2 relative ${isToday ? 'bg-blue-50 dark:bg-slate-800/50' : ''}`}>
          <span className={`text-xs sm:text-sm font-medium mb-1 ${isToday ? 'bg-blue-600 text-white w-6 h-6 flex items-center justify-center rounded-full' : 'text-slate-400'}`}>
            {day}
          </span>
          
          <div className="flex flex-wrap justify-center gap-1 w-full px-1">
             {workoutsOnDay.map((session, idx) => (
               <div key={idx} className="text-blue-500 dark:text-blue-400" title={session.planName}>
                  {getWorkoutIcon(session.planName, "w-3 h-3 md:w-4 md:h-4")}
               </div>
             ))}
          </div>
        </div>
      );
    }
    return days;
  };

  const monthNames = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];

  return (
    <div className="space-y-6 pb-20">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Hallo, {user.name} 👋</h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm">Bereit für dein Training?</p>
        </div>
        
        {/* Settings Button */}
        <button 
          onClick={() => onChangeView(AppView.SETTINGS)}
          className="p-3 bg-white dark:bg-slate-800 rounded-full shadow-sm text-slate-600 dark:text-slate-400 hover:text-blue-500 transition-colors border border-slate-200 dark:border-slate-700"
        >
            <SettingsIcon className="w-6 h-6" />
        </button>
      </header>

      {/* Plans Selection List (Horizontal Scroll) */}
      <div className="space-y-2">
        <h3 className="text-slate-500 dark:text-slate-400 text-xs uppercase font-bold tracking-wider">Verfügbare Pläne</h3>
        
        <div className="flex gap-3 overflow-x-auto pb-4 -mx-4 px-4 no-scrollbar">
            {plans.map(plan => {
              const isNext = plan.id === nextPlanId;
              return (
                <button
                  key={plan.id}
                  onClick={() => onStartPlan(plan)}
                  className={`
                    flex-shrink-0 w-28 h-28 rounded-2xl p-3 flex flex-col items-center justify-between transition-transform active:scale-95 shadow-lg relative overflow-hidden
                    ${isNext 
                      ? 'bg-lime-400 text-slate-900 shadow-lime-900/20' 
                      : 'bg-sky-500 text-white shadow-sky-900/20'
                    }
                  `}
                >
                  {/* Icon */}
                  <div className="flex-1 flex items-center justify-center">
                      {getWorkoutIcon(plan.name, "w-10 h-10")}
                  </div>

                  {/* Name */}
                  <div className="w-full text-center">
                    <p className="font-bold text-xs leading-tight line-clamp-2">
                        {plan.name}
                    </p>
                    <p className={`text-[10px] mt-0.5 font-medium opacity-80`}>
                        {plan.exercises.length} Übungen
                    </p>
                  </div>
                  
                  {isNext && (
                      <div className="absolute top-2 right-2 w-2 h-2 bg-slate-900 rounded-full animate-pulse"></div>
                  )}
                </button>
              );
            })}

            {/* Add Plan Button */}
            <button
                onClick={() => onChangeView(AppView.PLANS)}
                className="flex-shrink-0 w-28 h-28 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/50 flex flex-col items-center justify-center text-slate-400 hover:text-blue-400 hover:border-blue-400/50 transition-colors"
            >
                <Plus className="w-10 h-10 mb-2" />
                <span className="text-xs font-bold">Plan</span>
            </button>
        </div>
        
        {plans.length === 0 && (
          <div className="text-center py-4 text-xs text-slate-500">
             Keine Pläne gefunden. Füge einen hinzu!
          </div>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div 
          className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 active:scale-95 transition-transform shadow-sm"
          onClick={() => onChangeView(AppView.BODY)}
        >
          <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400 mb-2">
            <Activity className="w-4 h-4" />
            <span className="text-xs font-medium">Gewicht</span>
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">
            {lastMeasurement ? `${lastMeasurement.weight} kg` : '--'}
          </p>
        </div>
        
        <div 
          className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 active:scale-95 transition-transform shadow-sm"
          onClick={() => onChangeView(AppView.ANALYSIS)}
        >
           <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400 mb-2">
            <TrendingUp className="w-4 h-4" />
            <span className="text-xs font-medium">Total Workouts</span>
          </div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">
            {allSessions.length}
          </p>
        </div>
      </div>

      {/* Photo Reminder */}
      {photoReminder && (
        <div 
            className="bg-amber-500/10 border border-amber-500/50 rounded-xl p-4 flex items-center gap-4 cursor-pointer"
            onClick={() => onChangeView(AppView.BODY)}
        >
          <div className="bg-amber-500 p-2 rounded-full">
            <Camera className="w-6 h-6 text-white" />
          </div>
          <div>
            <h4 className="text-amber-600 dark:text-amber-400 font-bold text-sm">Sunday Check-in</h4>
            <p className="text-amber-600/80 dark:text-amber-200/80 text-xs">Zeit für deine wöchentlichen Progress-Fotos!</p>
          </div>
        </div>
      )}

      {/* Calendar View */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-sm">
        {/* Calendar Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
          <h3 className="text-slate-900 dark:text-white font-bold text-lg">
             {monthNames[currentDate.getMonth()]} <span className="text-slate-500">{currentDate.getFullYear()}</span>
          </h3>
          <div className="flex gap-2">
            <button onClick={prevMonth} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full text-slate-400 hover:text-slate-900 dark:hover:text-white">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button onClick={nextMonth} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full text-slate-400 hover:text-slate-900 dark:hover:text-white">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Weekdays */}
        <div className="grid grid-cols-7 text-center py-2 bg-slate-50 dark:bg-slate-800/50 text-xs font-medium text-slate-500 uppercase tracking-wider">
          <div>Mo</div>
          <div>Di</div>
          <div>Mi</div>
          <div>Do</div>
          <div>Fr</div>
          <div>Sa</div>
          <div>So</div>
        </div>

        {/* Days Grid */}
        <div className="grid grid-cols-7 bg-white dark:bg-slate-900/30">
          {renderCalendarDays()}
        </div>
        
        {/* Legend */}
        <div className="px-4 py-3 bg-slate-50 dark:bg-slate-800 text-[10px] text-slate-500 flex gap-3 justify-center">
            <div className="flex items-center gap-1"><Footprints className="w-3 h-3 text-slate-400"/> Beine</div>
            <div className="flex items-center gap-1"><ArrowUpFromLine className="w-3 h-3 text-slate-400"/> Push</div>
            <div className="flex items-center gap-1"><ArrowDownToLine className="w-3 h-3 text-slate-400"/> Pull</div>
        </div>
      </div>

    </div>
  );
};