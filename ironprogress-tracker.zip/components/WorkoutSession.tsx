import React, { useState, useEffect, useRef } from 'react';
import { WorkoutPlan, WorkoutSessionLog, WorkoutSetLog } from '../types';
import { storage } from '../services/storage';
import { Play, Check, Timer, ArrowLeft, Save, RefreshCw, X, Pause, Flame, Minus, Plus, ListOrdered } from 'lucide-react';

interface Props {
    onFinish: () => void;
    onCancel: () => void;
    initialPlan: WorkoutPlan | null;
}

/**
 * Smart Helper to parse rep strings specifically handling ranges like "15-20".
 * Prioritizes the UPPER bound of a range for the specific set index.
 */
const getSuggestedReps = (repsStr: string, setIndex: number): string => {
  if (!repsStr) return '0';

  // 1. Split by common delimiters to separate instructions for different sets
  // e.g. "15-20, 12-15, 10" or "Satz 1: 15-20\nSatz 2: 12-15"
  const parts = repsStr.split(/[,;\n]+/).map(s => s.trim()).filter(s => s.length > 0);

  // Determine which part of the string applies to the current set index
  let targetPart = parts[0];
  if (parts.length > 0) {
      if (setIndex < parts.length) {
          targetPart = parts[setIndex];
      } else {
          // If we are on Set 4 but only have 3 instructions, use the last one
          targetPart = parts[parts.length - 1];
      }
  }

  // 2. Look for explicit Range pattern "15-20" or "15 - 20"
  // We take the SECOND number (group 2) as the target rep count
  const rangeMatch = targetPart.match(/(\d+)\s*-\s*(\d+)/);
  if (rangeMatch) {
    return rangeMatch[2]; 
  }

  // 3. Look for "3 x 12" pattern (Sets x Reps)
  // Usually the second number is reps
  const xMatch = targetPart.match(/(\d+)\s*x\s*(\d+)/i);
  if (xMatch) {
    return xMatch[2];
  }

  // 4. Fallback: Just find the single largest number in that segment
  // (filtering out huge numbers to avoid artifacts like "2025")
  const allNums = targetPart.match(/\d+/g)?.map(Number).filter(n => n < 200) || [];
  if (allNums.length > 0) {
      return Math.max(...allNums).toString();
  }

  return '0';
};

export const WorkoutSession: React.FC<Props> = ({ onFinish, onCancel, initialPlan }) => {
  const [plans, setPlans] = useState<WorkoutPlan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<WorkoutPlan | null>(null);
  
  // Warmup State
  const [isWarmupMode, setIsWarmupMode] = useState(false);
  const [warmupSeconds, setWarmupSeconds] = useState(0);
  const [isWarmupTimerRunning, setIsWarmupTimerRunning] = useState(false);

  // Session State
  const [activeExerciseIndex, setActiveExerciseIndex] = useState(0);
  const [logs, setLogs] = useState<{ [exerciseName: string]: WorkoutSetLog[] }>({});
  const [showExerciseList, setShowExerciseList] = useState(false);
  
  // Rest Timer State
  const [restTimer, setRestTimer] = useState(0); // seconds
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  
  const timerIntervalRef = useRef<number | null>(null);
  const warmupIntervalRef = useRef<number | null>(null);

  // Inputs
  const [currentWeight, setCurrentWeight] = useState<string>('');
  const [currentReps, setCurrentReps] = useState<string>('');

  useEffect(() => {
    setPlans(storage.getPlans());
    
    // If initial plan provided, start immediately
    if (initialPlan) {
        handlePlanSelect(initialPlan);
    }

    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (warmupIntervalRef.current) clearInterval(warmupIntervalRef.current);
    };
  }, [initialPlan]);

  // Load inputs whenever active exercise changes
  useEffect(() => {
    if (!selectedPlan) return;
    const currentEx = selectedPlan.exercises[activeExerciseIndex];
    
    // Check if we already have logs for this exercise in this session
    const existingLogs = logs[currentEx.name];
    
    if (existingLogs && existingLogs.length > 0) {
        // If we come back to an exercise we already started, load the last values used
        const lastSet = existingLogs[existingLogs.length - 1];
        setCurrentWeight(String(lastSet.weight));
        
        // Suggest reps for the NEXT set
        const nextSetIdx = existingLogs.length;
        setCurrentReps(getSuggestedReps(currentEx.reps, nextSetIdx));
    } else {
        // New exercise for this session: Load historical data
        const lastWeight = storage.getLastLogForExercise(currentEx.name);
        setCurrentWeight(lastWeight ? lastWeight.toString() : '0');
        // Pre-fill Set 1 reps (index 0)
        setCurrentReps(getSuggestedReps(currentEx.reps, 0));
    }

    // Reset timer when switching exercises manually? 
    // Usually better to keep it running if it was running, 
    // but maybe safer to stop if switching context.
    // For now, let's keep it running if user is just checking the list.
  }, [activeExerciseIndex, selectedPlan]);


  // Rest Timer Logic
  useEffect(() => {
    if (isTimerRunning && restTimer > 0) {
      timerIntervalRef.current = window.setInterval(() => {
        setRestTimer(prev => prev - 1);
      }, 1000);
    } else if (restTimer === 0) {
      setIsTimerRunning(false);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isTimerRunning, restTimer]);

  // Warmup Timer Logic
  useEffect(() => {
    if (isWarmupTimerRunning) {
        warmupIntervalRef.current = window.setInterval(() => {
            setWarmupSeconds(prev => prev + 1);
        }, 1000);
    } else {
        if (warmupIntervalRef.current) clearInterval(warmupIntervalRef.current);
    }
    return () => {
        if (warmupIntervalRef.current) clearInterval(warmupIntervalRef.current);
    }
  }, [isWarmupTimerRunning]);

  const startRestTimer = (seconds: number = 120) => {
    setRestTimer(seconds);
    setIsTimerRunning(true);
  };

  const handlePlanSelect = (plan: WorkoutPlan) => {
    setSelectedPlan(plan);
    // Start in Warmup Mode
    setIsWarmupMode(true);
    setActiveExerciseIndex(0);
  };

  const finishWarmup = () => {
      setIsWarmupTimerRunning(false);
      setIsWarmupMode(false);
  };

  const adjustWeight = (amount: number) => {
      const val = parseFloat(currentWeight) || 0;
      // Ensure we don't go below 0 and handle float precision
      const newVal = Math.max(0, val + amount);
      // rounding to avoid 20.000000001
      setCurrentWeight(String(Math.round(newVal * 100) / 100));
  };

  const adjustReps = (amount: number) => {
    const val = parseInt(currentReps) || 0;
    const newVal = Math.max(0, val + amount);
    setCurrentReps(String(newVal));
  };

  const jumpToExercise = (index: number) => {
      setActiveExerciseIndex(index);
      setShowExerciseList(false);
  };

  const logSet = () => {
    if (!selectedPlan) return;
    const exercise = selectedPlan.exercises[activeExerciseIndex];
    
    const currentSetIndex = logs[exercise.name]?.length || 0;

    const newSet: WorkoutSetLog = {
      setNumber: currentSetIndex + 1,
      weight: parseFloat(currentWeight) || 0,
      reps: parseInt(currentReps) || 0,
      timestamp: Date.now(),
    };

    setLogs(prev => ({
      ...prev,
      [exercise.name]: [...(prev[exercise.name] || []), newSet]
    }));

    // Prepare inputs for the NEXT set
    // Calculate what the reps should be for the next set (index + 1)
    const nextSetIndex = currentSetIndex + 1;
    const nextSuggestedReps = getSuggestedReps(exercise.reps, nextSetIndex);
    
    // Update the input field with the suggestion for the next set
    if (nextSuggestedReps !== '0') {
        setCurrentReps(nextSuggestedReps);
    }

    // Trigger Timer
    startRestTimer(120);
  };

  const finishExercise = () => {
    if (!selectedPlan) return;
    if (activeExerciseIndex < selectedPlan.exercises.length - 1) {
      // Move to next index - the useEffect will handle data loading
      setActiveExerciseIndex(prev => prev + 1);
    } else {
      // Workout Done
      const session: WorkoutSessionLog = {
        id: crypto.randomUUID(),
        planId: selectedPlan.id,
        planName: selectedPlan.name,
        date: Date.now(),
        exercises: logs
      };
      // We could log warmup duration here if we extended the type, for now it's just for user feedback
      storage.saveSession(session);
      onFinish();
    }
  };

  const formatTime = (totalSeconds: number) => {
      const m = Math.floor(totalSeconds / 60);
      const s = totalSeconds % 60;
      return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // --- Render Selection Screen (Only if no plan selected) ---
  if (!selectedPlan) {
    return (
      <div className="space-y-6 pb-20">
        <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">Training starten</h2>
            <button 
                onClick={onCancel} 
                className="flex items-center gap-2 bg-slate-800 px-4 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
            >
                <ArrowLeft className="w-4 h-4" /> Zurück
            </button>
        </div>
        
        {plans.length > 0 ? (
          <div className="grid gap-4">
            <p className="text-slate-400">Wähle deinen heutigen Plan:</p>
            {plans.map(plan => (
              <button
                key={plan.id}
                onClick={() => handlePlanSelect(plan)}
                className="bg-slate-800 p-6 rounded-xl text-left border border-slate-700 hover:border-blue-500 hover:bg-slate-750 transition-all"
              >
                <h3 className="text-xl font-bold text-white">{plan.name}</h3>
                <div className="flex justify-between mt-2">
                   <span className="text-slate-400 text-sm">{plan.exercises.length} Übungen</span>
                   <span className="text-blue-400 text-sm">Starten →</span>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-slate-800/50 rounded-xl border border-slate-700 border-dashed flex flex-col items-center justify-center">
              <p className="text-slate-400 mb-6 text-lg">Noch keine Trainingspläne vorhanden.</p>
              <button 
                  onClick={onCancel} 
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-bold transition-colors"
              >
                  Zurück zum Dashboard
              </button>
          </div>
        )}
      </div>
    );
  }

  // --- Render Warm-up Mode ---
  if (isWarmupMode) {
    return (
        <div className="flex flex-col h-[calc(100vh-80px)]">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-bold text-lg">Aufwärmen</h3>
                <button onClick={onCancel} className="text-slate-400 hover:text-red-400">
                    <X className="w-6 h-6" />
                </button>
            </div>

            <div className="bg-slate-800 rounded-2xl p-6 shadow-lg flex-1 flex flex-col border border-slate-700 text-center justify-center items-center">
                <div className="bg-amber-500 p-4 rounded-full mb-6 shadow-lg shadow-amber-500/20">
                    <Flame className="w-10 h-10 text-white" />
                </div>

                <h2 className="text-3xl font-bold text-white mb-2">Warm-up Phase</h2>
                <div className="bg-slate-900/60 p-4 rounded-xl mb-6 w-full border border-slate-700">
                    <p className="text-amber-400 font-bold mb-2">Empfehlung:</p>
                    <p className="text-white text-lg">5-10 Minuten Laufband</p>
                    <div className="flex justify-center gap-4 mt-3 text-sm text-slate-300">
                        <span className="bg-slate-700 px-3 py-1 rounded-lg">5 km/h</span>
                        <span className="bg-slate-700 px-3 py-1 rounded-lg">15% Steigung</span>
                    </div>
                </div>

                {selectedPlan.warmup && (
                     <div className="text-sm text-slate-400 mb-8 max-w-xs">
                        <span className="uppercase text-xs font-bold opacity-50 block mb-1">Plan Details</span>
                        {selectedPlan.warmup}
                     </div>
                )}

                {/* Stopwatch */}
                <div className="mb-8">
                    <div className="font-mono text-6xl font-bold text-white tracking-wider">
                        {formatTime(warmupSeconds)}
                    </div>
                    <p className="text-slate-500 text-sm mt-2">Verstrichene Zeit</p>
                </div>

                <div className="w-full space-y-3">
                    <button 
                        onClick={() => setIsWarmupTimerRunning(!isWarmupTimerRunning)}
                        className={`w-full font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all text-lg ${isWarmupTimerRunning ? 'bg-slate-700 text-white hover:bg-slate-600' : 'bg-green-600 text-white hover:bg-green-700 shadow-lg shadow-green-900/20'}`}
                    >
                        {isWarmupTimerRunning ? <Pause className="w-6 h-6"/> : <Play className="w-6 h-6"/>}
                        {isWarmupTimerRunning ? 'Pause' : 'Start'}
                    </button>

                    {warmupSeconds > 0 && (
                        <button 
                            onClick={finishWarmup}
                            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl transition-all"
                        >
                            Fertig & Training starten
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
  }

  const currentExercise = selectedPlan.exercises[activeExerciseIndex];
  const setsDone = logs[currentExercise.name]?.length || 0;
  const targetSets = currentExercise.sets;
  const isExerciseDone = setsDone >= targetSets;

  // --- Render Active Workout ---
  return (
    <div className="flex flex-col h-[calc(100vh-80px)] relative">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <button onClick={() => setSelectedPlan(null)} className="text-slate-400 hover:text-white flex items-center gap-1">
          <ArrowLeft className="w-5 h-5" /> <span className="text-sm">Plan</span>
        </button>
        <div className="text-center">
          <h3 className="text-white font-bold text-sm sm:text-base">{selectedPlan.name}</h3>
          <p className="text-xs text-slate-400">Übung {activeExerciseIndex + 1} / {selectedPlan.exercises.length}</p>
        </div>
        <div className="flex gap-2">
            <button 
                onClick={() => setShowExerciseList(true)} 
                className="text-slate-400 hover:text-blue-400 p-1" 
                title="Übungsliste / Reihenfolge ändern"
            >
                <ListOrdered className="w-6 h-6" />
            </button>
            <button onClick={onCancel} className="text-slate-400 hover:text-red-400 p-1" title="Abbrechen">
                <X className="w-6 h-6" />
            </button>
        </div>
      </div>

      {/* Timer Banner (Improved) */}
      {isTimerRunning && (
        <div className="bg-red-600 text-white p-6 rounded-xl flex flex-col items-center justify-center gap-2 mb-6 shadow-[0_0_20px_rgba(220,38,38,0.6)] animate-pulse transition-all duration-300 ease-in-out transform scale-105">
          <div className="flex items-center gap-2">
             <Timer className="w-6 h-6" />
             <span className="uppercase text-xs font-bold tracking-widest opacity-80">Satzpause</span>
          </div>
          
          <div className="font-mono text-4xl font-bold my-1">
            {Math.floor(restTimer / 60)}:{(restTimer % 60).toString().padStart(2, '0')}
          </div>
          
          <button 
            onClick={() => setRestTimer(0)} 
            className="bg-white/20 px-6 py-2 rounded-full text-sm font-bold hover:bg-white/30 mt-2 transition-colors"
          >
            Training fortsetzen
          </button>
        </div>
      )}

      {/* Main Exercise Card */}
      <div className="bg-slate-800 rounded-2xl p-6 shadow-lg flex-1 flex flex-col border border-slate-700 overflow-hidden">
        <div className="mb-4">
          <h2 className="text-2xl font-bold text-white mb-1 leading-tight">{currentExercise.name}</h2>
          <p className="text-slate-400 text-sm mb-2">{currentExercise.equipment}</p>
          
          <div className="flex flex-wrap gap-2 mt-2">
             <div className="bg-slate-700 px-2 py-1 rounded text-xs text-slate-300">
                Ziel: {targetSets} Sätze
             </div>
             <div className="bg-slate-700 px-2 py-1 rounded text-xs text-slate-300">
                Reps: {currentExercise.reps}
             </div>
             {currentExercise.notes && (
                <div className="bg-slate-700 px-2 py-1 rounded text-xs text-slate-300 truncate max-w-full">
                   {currentExercise.notes}
                </div>
             )}
          </div>
        </div>

        {/* Previous Stats */}
        <div className="bg-slate-900/50 p-3 rounded-lg mb-4 flex items-center gap-2">
           <RefreshCw className="w-4 h-4 text-slate-500" />
           <span className="text-xs text-slate-400">
             Letztes Training: {storage.getLastLogForExercise(currentExercise.name) ? `${storage.getLastLogForExercise(currentExercise.name)} kg` : 'Noch keine Daten'}
           </span>
        </div>

        {/* Input Area */}
        {!isExerciseDone ? (
          <div className="space-y-4 mt-auto mb-2">
            <div className="grid grid-cols-2 gap-4">
              
              {/* Weight Section */}
              <div>
                <label className="block text-xs text-slate-400 mb-1">Gewicht (kg)</label>
                <div className="flex items-center bg-slate-700 rounded-t-xl border-b border-slate-600">
                    <button 
                        onClick={() => adjustWeight(-1.25)} 
                        className="h-14 w-12 flex items-center justify-center text-slate-300 hover:bg-slate-600 hover:text-white active:bg-slate-800 rounded-tl-xl transition-colors"
                    >
                        <Minus className="w-5 h-5" />
                    </button>
                    
                    <input 
                        type="number" 
                        value={currentWeight}
                        onChange={(e) => setCurrentWeight(e.target.value)}
                        className="w-full bg-transparent text-white text-3xl font-bold h-14 text-center focus:outline-none [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none"
                        placeholder="0"
                        inputMode="decimal"
                    />
                    
                    <button 
                        onClick={() => adjustWeight(1.25)}
                        className="h-14 w-12 flex items-center justify-center text-slate-300 hover:bg-slate-600 hover:text-white active:bg-slate-800 rounded-tr-xl transition-colors"
                    >
                        <Plus className="w-5 h-5" />
                    </button>
                </div>
                
                {/* Slider for Weight */}
                <input 
                  type="range" 
                  min="0" 
                  max="150" 
                  step="0.25" 
                  value={parseFloat(currentWeight) || 0}
                  onChange={(e) => setCurrentWeight(e.target.value)}
                  className="w-full h-4 bg-slate-600 rounded-b-xl appearance-none cursor-pointer accent-blue-500 block"
                />
              </div>

              {/* Reps Section - UPDATED */}
              <div>
                <label className="block text-xs text-slate-400 mb-1">Wdh.</label>
                <div className="flex items-center bg-slate-700 rounded-t-xl border-b border-slate-600">
                    <button 
                        onClick={() => adjustReps(-1)} 
                        className="h-14 w-12 flex items-center justify-center text-slate-300 hover:bg-slate-600 hover:text-white active:bg-slate-800 rounded-tl-xl transition-colors"
                    >
                        <Minus className="w-5 h-5" />
                    </button>
                    
                    <input 
                        type="number" 
                        value={currentReps}
                        onChange={(e) => setCurrentReps(e.target.value)}
                        className="w-full bg-transparent text-white text-3xl font-bold h-14 text-center focus:outline-none [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none"
                        placeholder="0"
                        inputMode="numeric"
                    />
                    
                    <button 
                        onClick={() => adjustReps(1)} 
                        className="h-14 w-12 flex items-center justify-center text-slate-300 hover:bg-slate-600 hover:text-white active:bg-slate-800 rounded-tr-xl transition-colors"
                    >
                        <Plus className="w-5 h-5" />
                    </button>
                </div>

                 {/* Slider for Reps - NEW */}
                 <input 
                  type="range" 
                  min="0" 
                  max="30" 
                  step="1" 
                  value={parseInt(currentReps) || 0}
                  onChange={(e) => setCurrentReps(e.target.value)}
                  className="w-full h-4 bg-slate-600 rounded-b-xl appearance-none cursor-pointer accent-blue-500 block"
                />
              </div>
            </div>

            <button 
              onClick={logSet}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white text-lg font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-blue-900/20"
            >
              <Check className="w-6 h-6" />
              Satz {setsDone + 1} loggen
            </button>
          </div>
        ) : (
          <div className="mt-auto mb-4 text-center animate-in zoom-in duration-300">
            <div className="bg-green-500/20 text-green-400 p-4 rounded-full inline-flex mb-4">
              <Check className="w-8 h-8" />
            </div>
            <h3 className="text-white font-bold text-xl mb-4">Übung abgeschlossen!</h3>
            <button 
              onClick={finishExercise}
              className="w-full bg-green-600 hover:bg-green-700 text-white text-lg font-bold py-4 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-green-900/20"
            >
              {activeExerciseIndex < selectedPlan.exercises.length - 1 ? (
                  <>
                    Nächste Übung <Play className="w-5 h-5 fill-current" />
                  </>
              ) : (
                  <>
                    Workout beenden <Save className="w-5 h-5" />
                  </>
              )}
            </button>
          </div>
        )}

        {/* Set History List for current exercise */}
        <div className="border-t border-slate-700 pt-4 mt-2 flex-1 overflow-hidden flex flex-col">
          <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Heutige Sätze</h4>
          <div className="space-y-2 overflow-y-auto no-scrollbar pr-1">
            {logs[currentExercise.name]?.map((set, idx) => (
              <div key={idx} className="flex justify-between text-sm text-slate-300 bg-slate-700/30 p-2 rounded items-center">
                <span className="text-slate-400 text-xs">Satz {set.setNumber}</span>
                <span className="font-mono font-bold text-white">{set.weight} <span className="text-slate-500 text-xs font-sans">kg</span> × {set.reps} <span className="text-slate-500 text-xs font-sans">wdh</span></span>
              </div>
            ))}
            {(!logs[currentExercise.name] || logs[currentExercise.name].length === 0) && (
                <p className="text-xs text-slate-600 italic text-center py-2">Noch keine Sätze geloggt.</p>
            )}
          </div>
        </div>
      </div>

      {/* Exercise List Overlay (Modal) */}
      {showExerciseList && (
          <div className="absolute inset-0 z-50 bg-slate-900/95 backdrop-blur-sm flex flex-col animate-in fade-in duration-200">
              <div className="flex items-center justify-between p-4 border-b border-slate-700">
                  <h3 className="font-bold text-white text-lg">Übersicht</h3>
                  <button onClick={() => setShowExerciseList(false)} className="p-2 bg-slate-800 rounded-full text-slate-400 hover:text-white">
                      <X className="w-6 h-6" />
                  </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  <p className="text-sm text-slate-400 mb-2">Wähle eine Übung, um zu springen:</p>
                  {selectedPlan.exercises.map((ex, idx) => {
                      const setsDoneCount = logs[ex.name]?.length || 0;
                      const isComplete = setsDoneCount >= ex.sets;
                      const isActive = idx === activeExerciseIndex;
                      
                      return (
                        <button 
                           key={idx}
                           onClick={() => jumpToExercise(idx)}
                           className={`w-full text-left p-4 rounded-xl border flex items-center justify-between transition-all ${
                               isActive 
                                 ? 'bg-blue-600/10 border-blue-500 shadow-md shadow-blue-900/20' 
                                 : isComplete 
                                   ? 'bg-slate-800/50 border-green-900/30 opacity-70' 
                                   : 'bg-slate-800 border-slate-700 hover:border-slate-500'
                           }`}
                        >
                            <div className="flex items-center gap-3">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                                    isActive ? 'bg-blue-600 text-white' : 
                                    isComplete ? 'bg-green-600 text-white' : 'bg-slate-700 text-slate-400'
                                }`}>
                                    {isComplete ? <Check className="w-4 h-4" /> : idx + 1}
                                </div>
                                <div>
                                    <p className={`font-bold ${isActive ? 'text-blue-400' : isComplete ? 'text-green-400 line-through' : 'text-white'}`}>
                                        {ex.name}
                                    </p>
                                    <p className="text-xs text-slate-500">{setsDoneCount} / {ex.sets} Sätze</p>
                                </div>
                            </div>
                            
                            {isActive && <div className="text-xs bg-blue-600 text-white px-2 py-1 rounded">Aktiv</div>}
                        </button>
                      );
                  })}
              </div>
          </div>
      )}
    </div>
  );
};