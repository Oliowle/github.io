
import React, { useState, useEffect, useRef } from 'react';
import { WorkoutPlan, ExercisePlan } from '../types';
import { storage } from '../services/storage';
import { parseWorkoutPlanImage } from '../services/geminiService';
import { Upload, Trash2, FileText, Loader2, Plus, FileType, AlertCircle, CheckCircle2, X, PenTool, Save, ArrowLeft } from 'lucide-react';
import { ExerciseSelector } from './ExerciseSelector';
import { ExerciseDef } from '../services/exerciseData';

export const PlanManager: React.FC = () => {
  const [plans, setPlans] = useState<WorkoutPlan[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Manual Creation State
  const [isCreatorOpen, setIsCreatorOpen] = useState(false);
  const [isExerciseSelectorOpen, setIsExerciseSelectorOpen] = useState(false);
  const [newPlanName, setNewPlanName] = useState('');
  const [newPlanExercises, setNewPlanExercises] = useState<ExercisePlan[]>([]);

  // Load plans on mount
  useEffect(() => {
    setPlans(storage.getPlans());
  }, []);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/') && file.type !== 'application/pdf') {
        setError("Bitte lade ein Bild (JPG, PNG) oder ein PDF hoch.");
        setSuccessMsg(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
    }

    const defaultName = file.name.split('.')[0];
    
    setIsUploading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const newPlans = await parseWorkoutPlanImage(file, defaultName);
      if (newPlans.length === 0) throw new Error("Keine gültigen Pläne in der Datei gefunden.");

      newPlans.forEach(plan => storage.savePlan(plan));
      setPlans(storage.getPlans());
      
      const planNames = newPlans.map(p => p.name).join(', ');
      setSuccessMsg(`${newPlans.length} Pläne erfolgreich importiert: ${planNames}`);
      
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Unbekannter Fehler beim Hochladen.");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDelete = (id: string) => {
    if (confirm("Plan wirklich löschen?")) {
      storage.deletePlan(id);
      setPlans(storage.getPlans());
    }
  };

  // --- Manual Creation Logic ---
  const startManualCreation = () => {
      setNewPlanName('');
      setNewPlanExercises([]);
      setIsCreatorOpen(true);
  };

  const handleAddExercise = (def: ExerciseDef) => {
      const newExercise: ExercisePlan = {
          name: def.name,
          equipment: def.category, // e.g. "Dumbbell"
          sets: 3,
          reps: "10-12",
          notes: ""
      };
      setNewPlanExercises([...newPlanExercises, newExercise]);
      setIsExerciseSelectorOpen(false);
  };

  const handleRemoveExercise = (index: number) => {
      const updated = [...newPlanExercises];
      updated.splice(index, 1);
      setNewPlanExercises(updated);
  };

  const handleUpdateExercise = (index: number, field: keyof ExercisePlan, value: string | number) => {
      const updated = [...newPlanExercises];
      updated[index] = { ...updated[index], [field]: value };
      setNewPlanExercises(updated);
  };

  const saveManualPlan = () => {
      if (!newPlanName.trim()) {
          alert("Bitte gib dem Plan einen Namen.");
          return;
      }
      if (newPlanExercises.length === 0) {
          alert("Füge mindestens eine Übung hinzu.");
          return;
      }

      const newPlan: WorkoutPlan = {
          id: crypto.randomUUID(),
          name: newPlanName,
          warmup: "Allgemeines Aufwärmen empfohlen.",
          exercises: newPlanExercises,
          createdAt: Date.now()
      };

      storage.savePlan(newPlan);
      setPlans(storage.getPlans());
      setIsCreatorOpen(false);
      setSuccessMsg(`Plan "${newPlanName}" erstellt!`);
  };

  // --- Render Builder View ---
  if (isCreatorOpen) {
      return (
          <div className="space-y-6 pb-20 animate-in fade-in slide-in-from-right-4 duration-300">
             <div className="flex items-center justify-between">
                 <button onClick={() => setIsCreatorOpen(false)} className="text-slate-400 hover:text-white flex items-center gap-2">
                     <ArrowLeft className="w-5 h-5"/> Zurück
                 </button>
                 <h2 className="text-xl font-bold text-white">Neuer Plan</h2>
                 <button onClick={saveManualPlan} className="text-blue-400 font-bold hover:text-blue-300">
                     Speichern
                 </button>
             </div>

             <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
                 <label className="text-xs text-slate-500 uppercase font-bold mb-1 block">Plan Name</label>
                 <input 
                    type="text" 
                    placeholder="z.B. Oberkörper B" 
                    value={newPlanName}
                    onChange={(e) => setNewPlanName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:border-blue-500 focus:outline-none"
                    autoFocus
                 />
             </div>

             <div className="space-y-3">
                 <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Übungen ({newPlanExercises.length})</h3>
                 </div>

                 {newPlanExercises.map((ex, idx) => (
                     <div key={idx} className="bg-slate-800 p-4 rounded-xl border border-slate-700 relative group">
                         <div className="flex justify-between items-start mb-3 pr-8">
                             <h4 className="font-bold text-white">{ex.name}</h4>
                         </div>
                         <button 
                             onClick={() => handleRemoveExercise(idx)}
                             className="absolute top-4 right-4 text-slate-600 hover:text-red-400"
                         >
                             <X className="w-5 h-5" />
                         </button>

                         <div className="grid grid-cols-2 gap-3">
                             <div>
                                 <label className="text-[10px] text-slate-500 block mb-1">Sätze</label>
                                 <input 
                                    type="number" 
                                    value={ex.sets}
                                    onChange={(e) => handleUpdateExercise(idx, 'sets', parseInt(e.target.value))}
                                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-sm text-white"
                                 />
                             </div>
                             <div>
                                 <label className="text-[10px] text-slate-500 block mb-1">Wdh.</label>
                                 <input 
                                    type="text" 
                                    value={ex.reps}
                                    onChange={(e) => handleUpdateExercise(idx, 'reps', e.target.value)}
                                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-sm text-white"
                                 />
                             </div>
                         </div>
                     </div>
                 ))}

                 <button 
                    onClick={() => setIsExerciseSelectorOpen(true)}
                    className="w-full py-4 border-2 border-dashed border-slate-700 rounded-xl text-slate-500 hover:text-blue-400 hover:border-blue-500/50 hover:bg-slate-800/50 transition-all flex items-center justify-center gap-2 font-bold"
                 >
                     <Plus className="w-5 h-5" /> Übung hinzufügen
                 </button>
             </div>

             {isExerciseSelectorOpen && (
                 <ExerciseSelector 
                    onSelect={handleAddExercise} 
                    onClose={() => setIsExerciseSelectorOpen(false)} 
                 />
             )}
          </div>
      );
  }

  // --- Default View ---
  return (
    <div className="space-y-6 pb-20">
      <h2 className="text-2xl font-bold text-white">Trainingspläne</h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Upload Card */}
          <div className={`
            relative rounded-xl p-6 text-center border-2 border-dashed transition-all duration-300 overflow-hidden flex flex-col items-center justify-center min-h-[160px]
            ${isUploading ? 'border-blue-500 bg-blue-500/10' : 
              error ? 'border-red-500 bg-red-500/5' : 
              successMsg ? 'border-green-500 bg-green-500/5' : 
              'border-slate-600 bg-slate-800 hover:border-blue-400 hover:bg-slate-750'}
          `}>
            
            <input 
              ref={fileInputRef}
              type="file" 
              accept="image/*,application/pdf" 
              onChange={handleFileUpload}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
              disabled={isUploading}
            />

            {isUploading ? (
              <div className="flex flex-col items-center justify-center">
                <Loader2 className="w-10 h-10 text-blue-400 animate-spin mb-3" />
                <p className="text-blue-100 font-bold text-sm">Analysiere...</p>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center">
                 <div className={`p-3 rounded-full mb-3 ${error ? 'bg-red-500/20' : successMsg ? 'bg-green-500/20' : 'bg-slate-700'}`}>
                    {error ? <AlertCircle className="w-6 h-6 text-red-400" /> : 
                     successMsg ? <CheckCircle2 className="w-6 h-6 text-green-400" /> : 
                     <Upload className="w-6 h-6 text-blue-400" />}
                 </div>
                 
                 <h3 className="text-white font-bold text-sm">
                   {error ? 'Fehler' : successMsg ? 'Erfolg' : 'Plan scannen'}
                 </h3>
                 <p className="text-slate-400 text-xs mt-1 max-w-[150px]">
                   {error ? 'Erneut versuchen' : successMsg ? 'Weitere hinzufügen' : 'Foto oder PDF hochladen'}
                 </p>
              </div>
            )}
          </div>

          {/* Manual Create Card */}
          <button 
              onClick={startManualCreation}
              className="rounded-xl p-6 text-center border-2 border-slate-700 bg-slate-800 hover:border-blue-400 hover:bg-slate-750 transition-all flex flex-col items-center justify-center min-h-[160px]"
          >
              <div className="p-3 rounded-full mb-3 bg-slate-700">
                  <PenTool className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="text-white font-bold text-sm">Manuell erstellen</h3>
              <p className="text-slate-400 text-xs mt-1 max-w-[150px]">
                  Plan aus Datenbank zusammenstellen
              </p>
          </button>
      </div>

      {/* Plans List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
            <h3 className="text-slate-400 text-sm font-medium uppercase tracking-wider">Deine Pläne</h3>
            <span className="text-xs text-slate-600 bg-slate-800 px-2 py-1 rounded-full">{plans.length}</span>
        </div>
        
        {plans.length > 0 ? (
          plans.map(plan => (
            <div key={plan.id} className="bg-slate-800 rounded-xl p-5 border border-slate-700 shadow-sm hover:border-slate-600 transition-colors group">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-bold text-white group-hover:text-blue-400 transition-colors">{plan.name}</h3>
                  <p className="text-slate-500 text-xs mt-1">Hinzugefügt am {new Date(plan.createdAt).toLocaleDateString()}</p>
                </div>
                <button 
                  onClick={() => handleDelete(plan.id)}
                  className="text-slate-600 hover:text-red-400 transition-colors p-2 hover:bg-red-500/10 rounded-lg"
                  title="Löschen"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
              
              <div className="flex items-center gap-2 text-slate-400 text-sm bg-slate-900/30 p-2 rounded-lg w-fit">
                 <FileText className="w-4 h-4 text-blue-500" />
                 <span className="font-medium text-slate-300">{plan.exercises.length}</span>
                 <span className="text-slate-500">Übungen</span>
              </div>
            </div>
          ))
        ) : (
           <div className="text-center py-8 px-4 border border-slate-700 border-dashed rounded-xl bg-slate-800/30">
                <p className="text-slate-400 font-medium text-sm">Noch keine Pläne vorhanden.</p>
           </div>
        )}
      </div>
    </div>
  );
};
