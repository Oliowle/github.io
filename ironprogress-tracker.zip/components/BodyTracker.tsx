import React, { useState, useEffect, useRef } from 'react';
import { BodyMeasurements, ProgressPhoto, PhotoPerspective } from '../types';
import { storage } from '../services/storage';
import { Camera, RotateCcw, Save, X, Ruler, Images, ChevronLeft, ChevronRight, Calendar, History } from 'lucide-react';

export const BodyTracker: React.FC = () => {
  const [mode, setMode] = useState<'MEASURE' | 'PHOTO'>('MEASURE');
  const [measurements, setMeasurements] = useState<BodyMeasurements[]>([]);
  
  // Measurement Form
  const [form, setForm] = useState<BodyMeasurements>({
    date: Date.now(), weight: 0, arm: 0, chest: 0, waist: 0, hips: 0, leg: 0, calves: 0
  });

  // Camera State
  const [cameraOpen, setCameraOpen] = useState(false);
  const [perspective, setPerspective] = useState<PhotoPerspective>('front');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [lastPhoto, setLastPhoto] = useState<string | null>(null);

  // Gallery State
  const [galleryPerspective, setGalleryPerspective] = useState<PhotoPerspective | null>(null);
  const [galleryIndex, setGalleryIndex] = useState(0);
  const [currentGalleryPhotos, setCurrentGalleryPhotos] = useState<ProgressPhoto[]>([]);

  useEffect(() => {
    // Sort measurements by date descending (newest first)
    const sorted = storage.getMeasurements().sort((a, b) => b.date - a.date);
    setMeasurements(sorted);
  }, []);

  // Translations
  const measurementLabels: Record<string, string> = {
    weight: 'Gewicht (kg)',
    chest: 'Brust (cm)',
    arm: 'Arm (cm)',
    waist: 'Taille (cm)',
    hips: 'Hüfte (cm)',
    leg: 'Oberschenkel (cm)',
    calves: 'Waden (cm)'
  };

  const perspectiveLabels: Record<PhotoPerspective, string> = {
    front: 'Vorne',
    side: 'Seite',
    back: 'Hinten',
    biceps: 'Bizeps'
  };

  // Camera Logic
  const startCamera = async (p: PhotoPerspective) => {
    setPerspective(p);
    const previous = storage.getLatestPhoto(p);
    setLastPhoto(previous ? previous.imageData : null);
    setCameraOpen(true);

    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' }, // Prefer back camera
        audio: false 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (e) {
      console.error("Camera Error", e);
      alert("Kamera-Zugriff verweigert oder nicht verfügbar.");
      setCameraOpen(false);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setCameraOpen(false);
  };

  const takePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    if (context) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      
      const newPhoto: ProgressPhoto = {
        id: crypto.randomUUID(),
        date: Date.now(),
        perspective,
        imageData: dataUrl
      };
      
      storage.addPhoto(newPhoto);
      stopCamera();
      alert("Foto gespeichert!");
    }
  };

  const saveMeasurements = () => {
    storage.addMeasurement({ ...form, date: Date.now() });
    // Refresh list
    const sorted = storage.getMeasurements().sort((a, b) => b.date - a.date);
    setMeasurements(sorted);
    alert("Daten gespeichert!");
    setForm({ date: Date.now(), weight: 0, arm: 0, chest: 0, waist: 0, hips: 0, leg: 0, calves: 0 });
  };

  // --- Gallery Logic ---
  const openGallery = (p: PhotoPerspective) => {
    // Get photos for this perspective, sorted by date DESC (newest first)
    const photos = storage.getPhotos()
        .filter(photo => photo.perspective === p)
        .sort((a, b) => b.date - a.date);
    
    if (photos.length === 0) {
        alert("Noch keine Fotos für diese Ansicht vorhanden.");
        return;
    }

    setCurrentGalleryPhotos(photos);
    setGalleryIndex(0);
    setGalleryPerspective(p);
  };

  const closeGallery = () => {
    setGalleryPerspective(null);
    setCurrentGalleryPhotos([]);
    setGalleryIndex(0);
  };

  const nextPhoto = () => {
    if (galleryIndex < currentGalleryPhotos.length - 1) {
        setGalleryIndex(prev => prev + 1);
    }
  };

  const prevPhoto = () => {
    if (galleryIndex > 0) {
        setGalleryIndex(prev => prev - 1);
    }
  };

  // --- Ghost Camera View ---
  if (cameraOpen) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex flex-col">
        <div className="relative flex-1 overflow-hidden">
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            className="absolute inset-0 w-full h-full object-cover"
          />
          
          {/* Ghost Overlay */}
          {lastPhoto && (
            <img 
              src={lastPhoto} 
              alt="Ghost" 
              className="absolute inset-0 w-full h-full object-cover opacity-30 pointer-events-none grayscale filter contrast-125"
            />
          )}
          
          <canvas ref={canvasRef} className="hidden" />

          <div className="absolute top-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
            {perspectiveLabels[perspective]}
          </div>
          
          <button 
            onClick={stopCamera}
            className="absolute top-4 right-4 text-white bg-black/50 p-2 rounded-full"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="bg-black p-6 flex justify-center items-center gap-8 pb-10">
           <p className="text-white text-xs absolute bottom-24 w-full text-center opacity-70">
              Nutze das Geisterbild zur Ausrichtung
           </p>
           <div 
             onClick={takePhoto}
             className="w-20 h-20 bg-white rounded-full border-4 border-slate-300 flex items-center justify-center cursor-pointer hover:scale-105 transition-transform"
           >
             <div className="w-16 h-16 bg-white rounded-full border-2 border-black" />
           </div>
        </div>
      </div>
    );
  }

  // --- Gallery Slideshow View ---
  if (galleryPerspective && currentGalleryPhotos.length > 0) {
      const currentPhoto = currentGalleryPhotos[galleryIndex];
      const dateStr = new Date(currentPhoto.date).toLocaleDateString('de-DE', { 
          year: 'numeric', month: 'long', day: 'numeric',
          hour: '2-digit', minute: '2-digit'
      });

      return (
        <div className="fixed inset-0 bg-slate-900 z-50 flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-4 bg-slate-800 border-b border-slate-700">
                <div className="text-white font-bold text-lg flex items-center gap-2">
                    <Images className="w-5 h-5 text-blue-400" />
                    {perspectiveLabels[galleryPerspective]}
                    <span className="text-xs text-slate-400 font-normal bg-slate-700 px-2 py-0.5 rounded-full">
                        {galleryIndex + 1} / {currentGalleryPhotos.length}
                    </span>
                </div>
                <button onClick={closeGallery} className="text-slate-400 hover:text-white p-1 bg-slate-700 rounded-full">
                    <X className="w-6 h-6" />
                </button>
            </div>

            {/* Main Image Area */}
            <div className="flex-1 relative flex items-center justify-center bg-black overflow-hidden">
                <img 
                    src={currentPhoto.imageData} 
                    alt="Progress" 
                    className="max-w-full max-h-full object-contain"
                />

                {/* Navigation Arrows */}
                {galleryIndex > 0 && (
                    <button 
                        onClick={prevPhoto}
                        className="absolute left-4 p-3 bg-black/50 text-white rounded-full hover:bg-black/70 backdrop-blur-sm transition-all"
                    >
                        <ChevronLeft className="w-8 h-8" />
                    </button>
                )}
                {galleryIndex < currentGalleryPhotos.length - 1 && (
                    <button 
                        onClick={nextPhoto}
                        className="absolute right-4 p-3 bg-black/50 text-white rounded-full hover:bg-black/70 backdrop-blur-sm transition-all"
                    >
                        <ChevronRight className="w-8 h-8" />
                    </button>
                )}
            </div>

            {/* Footer with Date and Slider */}
            <div className="bg-slate-800 p-6 flex flex-col items-center border-t border-slate-700">
                <div className="flex items-center gap-2 text-blue-400 mb-1">
                    <Calendar className="w-4 h-4" />
                    <span className="text-xs font-bold uppercase tracking-wider">Aufnahmedatum</span>
                </div>
                <p className="text-white text-xl font-medium">
                    {dateStr}
                </p>
                {galleryIndex === 0 && (
                    <p className="text-green-400 text-xs mt-2 font-bold">Neuestes Foto</p>
                )}
                {galleryIndex === currentGalleryPhotos.length - 1 && currentGalleryPhotos.length > 1 && (
                    <p className="text-amber-400 text-xs mt-2 font-bold">Ältestes Foto</p>
                )}

                {/* Slider Control */}
                {currentGalleryPhotos.length > 1 && (
                    <div className="w-full max-w-xs mt-6 flex items-center gap-3">
                        <span className="text-[10px] text-slate-500 font-bold uppercase">Neu</span>
                        <input
                            type="range"
                            min="0"
                            max={currentGalleryPhotos.length - 1}
                            step="1"
                            value={galleryIndex}
                            onChange={(e) => setGalleryIndex(parseInt(e.target.value))}
                            className="flex-1 h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-blue-500"
                        />
                        <span className="text-[10px] text-slate-500 font-bold uppercase">Alt</span>
                    </div>
                )}
            </div>
        </div>
      );
  }

  return (
    <div className="space-y-6 pb-20">
      <div className="flex gap-4 mb-4 bg-slate-800 p-1 rounded-lg">
        <button 
          onClick={() => setMode('MEASURE')}
          className={`flex-1 py-2 text-sm font-bold rounded-md transition-colors ${mode === 'MEASURE' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
        >
          Messungen
        </button>
        <button 
          onClick={() => setMode('PHOTO')}
          className={`flex-1 py-2 text-sm font-bold rounded-md transition-colors ${mode === 'PHOTO' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
        >
          Fotos
        </button>
      </div>

      {mode === 'MEASURE' ? (
        <div className="space-y-6">
          <div className="bg-slate-800 p-6 rounded-xl border border-slate-700">
            <h3 className="text-white font-bold mb-4 flex items-center gap-2">
                <Ruler className="w-5 h-5" /> Neue Messung
            </h3>
            <div className="grid grid-cols-2 gap-4">
              {Object.keys(measurementLabels).map((field) => (
                <div key={field}>
                   <label className="text-xs text-slate-400 uppercase block mb-1">
                     {measurementLabels[field]}
                   </label>
                   <input 
                      type="number" 
                      className="w-full bg-slate-700 text-white p-2 rounded border border-slate-600 focus:outline-none focus:border-blue-500 transition-colors"
                      placeholder="0"
                      value={(form as any)[field] || ''}
                      onChange={(e) => setForm({...form, [field]: parseFloat(e.target.value)})}
                   />
                </div>
              ))}
            </div>
            <button 
              onClick={saveMeasurements}
              className="w-full mt-6 bg-green-600 text-white font-bold py-3 rounded-lg hover:bg-green-700 transition-colors shadow-lg shadow-green-900/20"
            >
              Speichern
            </button>
          </div>

          {/* History Table */}
          <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
              <div className="p-4 border-b border-slate-700 flex items-center gap-2">
                 <History className="w-5 h-5 text-blue-400" />
                 <h3 className="text-white font-bold">Mess-Verlauf</h3>
              </div>
              <div className="overflow-x-auto">
                 <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs uppercase bg-slate-750 text-slate-200">
                        <tr>
                            <th className="px-4 py-3">Datum</th>
                            <th className="px-4 py-3">Gewicht</th>
                            <th className="px-4 py-3">Brust</th>
                            <th className="px-4 py-3">Arm</th>
                            <th className="px-4 py-3">Bauch</th>
                            <th className="px-4 py-3">Bein</th>
                        </tr>
                    </thead>
                    <tbody>
                        {measurements.map((m, idx) => (
                            <tr key={idx} className="border-b border-slate-700 last:border-0 hover:bg-slate-750/50">
                                <td className="px-4 py-3 font-medium text-white whitespace-nowrap">
                                    {new Date(m.date).toLocaleDateString('de-DE')}
                                </td>
                                <td className="px-4 py-3">{m.weight} kg</td>
                                <td className="px-4 py-3">{m.chest} cm</td>
                                <td className="px-4 py-3">{m.arm} cm</td>
                                <td className="px-4 py-3">{m.waist} cm</td>
                                <td className="px-4 py-3">{m.leg} cm</td>
                            </tr>
                        ))}
                        {measurements.length === 0 && (
                            <tr>
                                <td colSpan={6} className="px-4 py-6 text-center italic opacity-50">
                                    Noch keine Messungen gespeichert.
                                </td>
                            </tr>
                        )}
                    </tbody>
                 </table>
              </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
           <div className="grid grid-cols-2 gap-4">
              {(['front', 'side', 'back', 'biceps'] as PhotoPerspective[]).map(p => (
                <div key={p} className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden flex flex-col h-44 relative group">
                    {/* Background Preview */}
                    {storage.getLatestPhoto(p) && (
                        <img 
                            src={storage.getLatestPhoto(p)?.imageData} 
                            className="absolute inset-0 w-full h-full object-cover opacity-40" 
                            alt="preview"
                        />
                    )}
                    
                    {/* Main Action (Camera) */}
                    <button 
                        onClick={() => startCamera(p)}
                        className="flex-1 flex flex-col items-center justify-center z-10 w-full hover:bg-white/5 transition-colors"
                    >
                         <Camera className="w-8 h-8 text-white mb-2 drop-shadow-md" />
                         <span className="text-white font-bold capitalize drop-shadow-md">{perspectiveLabels[p]}</span>
                    </button>

                    {/* Secondary Action (Gallery) */}
                    <button 
                        onClick={() => openGallery(p)}
                        className="z-10 bg-slate-900/80 backdrop-blur-sm text-blue-400 py-2 text-xs font-bold border-t border-slate-700 flex items-center justify-center gap-1 hover:bg-blue-600 hover:text-white transition-colors"
                    >
                        <Images className="w-3 h-3" /> Verlauf
                    </button>
                </div>
              ))}
           </div>
           <p className="text-xs text-slate-500 text-center mt-4 bg-slate-800/50 p-3 rounded-lg">
             <span className="font-bold">Tipp:</span> Klicke auf das Kamera-Icon, um ein neues Foto mit 
             Ghost-Overlay zu machen. Klicke auf "Verlauf", um deine Fortschritts-Diashow zu sehen.
           </p>
        </div>
      )}
    </div>
  );
};