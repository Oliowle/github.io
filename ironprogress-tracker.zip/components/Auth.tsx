import React, { useState } from 'react';
import { User } from '../types';
import { storage } from '../services/storage';
import { Dumbbell, UserPlus, LogIn } from 'lucide-react';

interface Props {
  onLogin: (user: User) => void;
}

export const Auth: React.FC<Props> = ({ onLogin }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email || !password) {
        setError("Bitte fülle alle Pflichtfelder aus.");
        return;
    }

    try {
        if (isRegistering) {
            if (!name) {
                setError("Bitte gib deinen Namen ein.");
                return;
            }
            // Registrierung versuchen
            const success = storage.registerUser(email, name, password);
            if (success) {
                // Automatisch einloggen nach Registrierung
                const user = storage.loginUser(email, password);
                if (user) onLogin(user);
            } else {
                setError("Diese E-Mail-Adresse wird bereits verwendet.");
            }
        } else {
            // Login versuchen
            const user = storage.loginUser(email, password);
            if (user) {
                onLogin(user);
            } else {
                setError("E-Mail oder Passwort falsch.");
            }
        }
    } catch (err) {
        setError("Ein Fehler ist aufgetreten.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-slate-800 p-8 rounded-2xl shadow-2xl w-full max-w-md border border-slate-700">
        <div className="flex justify-center mb-6">
          <div className="bg-blue-600 p-3 rounded-full shadow-lg shadow-blue-900/50">
            <Dumbbell className="w-8 h-8 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-center text-white mb-2">IronProgress</h1>
        <p className="text-slate-400 text-center mb-8">Dein intelligenter Workout-Begleiter</p>
        
        {/* Tabs */}
        <div className="flex mb-6 bg-slate-700/50 rounded-lg p-1">
            <button 
                onClick={() => { setIsRegistering(false); setError(null); }}
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${!isRegistering ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'}`}
            >
                Anmelden
            </button>
            <button 
                onClick={() => { setIsRegistering(true); setError(null); }}
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${isRegistering ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'}`}
            >
                Registrieren
            </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegistering && (
            <div className="animate-in slide-in-from-top-2 fade-in duration-300">
                <label className="block text-sm font-medium text-slate-300 mb-1">Name</label>
                <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
                placeholder="Dein Name"
                autoComplete="name"
                />
            </div>
          )}
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">E-Mail</label>
            <input 
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
              placeholder="name@example.com"
              autoCapitalize="none"
              autoComplete="email"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Passwort</label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
              placeholder="••••••••"
              autoComplete={isRegistering ? "new-password" : "current-password"}
            />
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-200 text-sm p-3 rounded-lg animate-in shake">
                {error}
            </div>
          )}

          <button 
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition-colors mt-4 flex items-center justify-center gap-2"
          >
            {isRegistering ? <UserPlus className="w-5 h-5" /> : <LogIn className="w-5 h-5" />}
            {isRegistering ? 'Konto erstellen' : 'Einloggen'}
          </button>
        </form>
        
        <div className="mt-6 text-center text-xs text-slate-500">
          Lokal gespeichert • Keine Cloud • KI-Powered
        </div>
      </div>
    </div>
  );
};