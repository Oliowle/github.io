import React, { useMemo, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { storage } from '../services/storage';
import { WorkoutSessionLog } from '../types';
import { BarChart3, Ruler, Dumbbell } from 'lucide-react';

export const ProgressCharts: React.FC = () => {
  const [mode, setMode] = useState<'EXERCISE' | 'BODY'>('EXERCISE');
  const sessions = useMemo(() => storage.getSessions(), []);
  const measurements = useMemo(() => storage.getMeasurements(), []);

  // Exercise State
  const [selectedExercise, setSelectedExercise] = useState<string>('');
  
  // Body State
  const [selectedBodyMetric, setSelectedBodyMetric] = useState<string>('weight');

  // Available Exercises
  const exerciseNames = useMemo(() => {
    const names = new Set<string>();
    sessions.forEach(s => {
        Object.keys(s.exercises).forEach(k => names.add(k));
    });
    return Array.from(names).sort();
  }, [sessions]);

  // Available Body Metrics
  const bodyMetrics = [
      { key: 'weight', label: 'Gewicht (kg)' },
      { key: 'chest', label: 'Brust (cm)' },
      { key: 'arm', label: 'Arm (cm)' },
      { key: 'waist', label: 'Taille (cm)' },
      { key: 'hips', label: 'Hüfte (cm)' },
      { key: 'leg', label: 'Oberschenkel (cm)' },
      { key: 'calves', label: 'Waden (cm)' },
  ];

  // Set default exercise
  if (!selectedExercise && exerciseNames.length > 0) {
      setSelectedExercise(exerciseNames[0]);
  }

  // --- Prepare Data based on Mode ---
  const chartData = useMemo(() => {
    if (mode === 'EXERCISE') {
        if (!selectedExercise) return [];
        return sessions
          .filter(s => s.exercises[selectedExercise])
          .map(s => {
            const sets = s.exercises[selectedExercise];
            const maxWeight = Math.max(...sets.map(set => set.weight));
            const volume = sets.reduce((acc, set) => acc + (set.weight * set.reps), 0);
            return {
              date: new Date(s.date).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' }),
              value1: maxWeight, // Maps to Weight Chart
              value2: volume     // Maps to Volume Chart
            };
          });
    } else {
        // Body Mode
        return measurements
            .sort((a, b) => a.date - b.date) // Chronological order
            .map(m => ({
                date: new Date(m.date).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' }),
                value1: (m as any)[selectedBodyMetric] || 0
            }));
    }
  }, [sessions, measurements, mode, selectedExercise, selectedBodyMetric]);

  return (
    <div className="space-y-6 pb-20">
      <h2 className="text-2xl font-bold text-white flex items-center gap-2">
        <BarChart3 className="w-6 h-6" /> Analyse & Fortschritt
      </h2>

      {/* Mode Toggle */}
      <div className="bg-slate-800 p-1 rounded-lg flex">
          <button 
             onClick={() => setMode('EXERCISE')}
             className={`flex-1 py-2 rounded-md text-sm font-bold flex items-center justify-center gap-2 transition-all ${mode === 'EXERCISE' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
          >
              <Dumbbell className="w-4 h-4" /> Training
          </button>
          <button 
             onClick={() => setMode('BODY')}
             className={`flex-1 py-2 rounded-md text-sm font-bold flex items-center justify-center gap-2 transition-all ${mode === 'BODY' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
          >
              <Ruler className="w-4 h-4" /> Körper
          </button>
      </div>

      {/* Controls */}
      <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
        <label className="text-xs text-slate-400 uppercase mb-2 block">
            {mode === 'EXERCISE' ? 'Übung wählen' : 'Messwert wählen'}
        </label>
        
        {mode === 'EXERCISE' ? (
            <select 
              className="w-full bg-slate-700 text-white p-3 rounded-lg outline-none border border-slate-600 focus:border-blue-500"
              value={selectedExercise}
              onChange={(e) => setSelectedExercise(e.target.value)}
            >
              {exerciseNames.length === 0 && <option>Keine Trainingsdaten</option>}
              {exerciseNames.map(name => (
                <option key={name} value={name}>{name}</option>
              ))}
            </select>
        ) : (
            <select 
              className="w-full bg-slate-700 text-white p-3 rounded-lg outline-none border border-slate-600 focus:border-blue-500"
              value={selectedBodyMetric}
              onChange={(e) => setSelectedBodyMetric(e.target.value)}
            >
              {bodyMetrics.map(m => (
                <option key={m.key} value={m.key}>{m.label}</option>
              ))}
            </select>
        )}
      </div>

      {/* Charts */}
      {chartData.length > 0 ? (
          <>
            {/* Chart 1 */}
            <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 h-72">
                <h3 className="text-white font-medium mb-4 text-sm">
                    {mode === 'EXERCISE' ? 'Maximalgewicht (kg)' : bodyMetrics.find(m => m.key === selectedBodyMetric)?.label || 'Verlauf'}
                </h3>
                <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickMargin={10} />
                    <YAxis stroke="#94a3b8" fontSize={12} domain={['auto', 'auto']} />
                    <Tooltip 
                        contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#fff' }}
                        labelStyle={{ color: '#94a3b8' }}
                    />
                    <Line type="monotone" dataKey="value1" stroke="#3b82f6" strokeWidth={3} dot={{r: 4, fill: '#3b82f6'}} activeDot={{r: 6}} />
                </LineChart>
                </ResponsiveContainer>
            </div>

            {/* Chart 2 (Only for Exercise Mode: Volume) */}
            {mode === 'EXERCISE' && (
                <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 h-72">
                    <h3 className="text-white font-medium mb-4 text-sm">Volumen (kg × Reps)</h3>
                    <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                        <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickMargin={10} />
                        <YAxis stroke="#94a3b8" fontSize={12} />
                        <Tooltip 
                            contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#fff' }}
                            labelStyle={{ color: '#94a3b8' }}
                        />
                        <Line type="monotone" dataKey="value2" stroke="#10b981" strokeWidth={3} dot={{r: 4, fill: '#10b981'}} activeDot={{r: 6}} />
                    </LineChart>
                    </ResponsiveContainer>
                </div>
            )}
          </>
      ) : (
          <div className="text-center py-10 bg-slate-800/50 rounded-xl border border-slate-700 border-dashed">
              <p className="text-slate-400">Keine Daten für den gewählten Zeitraum vorhanden.</p>
          </div>
      )}
    </div>
  );
};