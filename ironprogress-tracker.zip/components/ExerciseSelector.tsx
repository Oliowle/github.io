
import React, { useState, useMemo } from 'react';
import { EXERCISE_DATABASE, ExerciseDef, BodyPart } from '../services/exerciseData';
import { Search, X, Dumbbell, Filter } from 'lucide-react';

interface Props {
  onSelect: (exercise: ExerciseDef) => void;
  onClose: () => void;
}

export const ExerciseSelector: React.FC<Props> = ({ onSelect, onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBodyPart, setSelectedBodyPart] = useState<BodyPart | 'All'>('All');

  const bodyParts: BodyPart[] = ['Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Core', 'Cardio', 'Full Body'];

  const filteredExercises = useMemo(() => {
    let result = EXERCISE_DATABASE;

    if (selectedBodyPart !== 'All') {
      result = result.filter(ex => ex.bodyPart === selectedBodyPart);
    }

    if (searchTerm) {
      const lowerSearch = searchTerm.toLowerCase();
      result = result.filter(ex => ex.name.toLowerCase().includes(lowerSearch));
    }

    // Sort alphabetically
    return result.sort((a, b) => a.name.localeCompare(b.name));
  }, [searchTerm, selectedBodyPart]);

  // Group by first letter
  const groupedExercises = useMemo(() => {
    const groups: { [key: string]: ExerciseDef[] } = {};
    filteredExercises.forEach(ex => {
      const letter = ex.name.charAt(0).toUpperCase();
      if (!groups[letter]) groups[letter] = [];
      groups[letter].push(ex);
    });
    return groups;
  }, [filteredExercises]);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/95 backdrop-blur-sm flex flex-col animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-slate-800 border-b border-slate-700 p-4 pb-2">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-white text-lg">Übung hinzufügen</h3>
          <button 
            onClick={onClose} 
            className="p-2 bg-slate-700 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
          <input 
            type="text" 
            placeholder="Suchen..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 text-white rounded-xl pl-10 pr-4 py-3 border border-slate-700 focus:border-blue-500 focus:outline-none"
            autoFocus
          />
        </div>

        {/* Filters */}
        <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
           <button 
             onClick={() => setSelectedBodyPart('All')}
             className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-colors ${selectedBodyPart === 'All' ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-400 hover:text-white'}`}
           >
             Alle
           </button>
           {bodyParts.map(bp => (
             <button 
               key={bp}
               onClick={() => setSelectedBodyPart(bp)}
               className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-colors ${selectedBodyPart === bp ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-400 hover:text-white'}`}
             >
               {bp}
             </button>
           ))}
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto p-4 relative">
        {Object.keys(groupedExercises).length === 0 ? (
           <div className="text-center py-10 text-slate-500">
             Keine Übungen gefunden.
           </div>
        ) : (
          Object.keys(groupedExercises).sort().map(letter => (
            <div key={letter} className="mb-6">
              <h4 className="text-blue-500 font-bold text-sm mb-2 sticky top-0 bg-slate-900/90 py-1 px-2">{letter}</h4>
              <div className="space-y-1">
                {groupedExercises[letter].map(ex => (
                  <button
                    key={ex.id}
                    onClick={() => onSelect(ex)}
                    className="w-full flex items-center gap-4 p-3 rounded-xl hover:bg-slate-800 border border-transparent hover:border-slate-700 transition-all text-left group"
                  >
                    {/* Placeholder Icon / Thumbnail */}
                    <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-slate-500 group-hover:bg-slate-700 group-hover:text-blue-400 transition-colors">
                       <Dumbbell className="w-6 h-6" />
                    </div>
                    
                    <div className="flex-1">
                      <p className="font-bold text-slate-200 group-hover:text-white">{ex.name}</p>
                      <div className="flex gap-2 mt-0.5">
                        <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-500">{ex.bodyPart}</span>
                        <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-500">{ex.category}</span>
                      </div>
                    </div>
                    
                    <div className="bg-slate-800 p-1.5 rounded-full text-slate-500 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                       <div className="w-4 h-4 flex items-center justify-center font-bold text-lg leading-none">+</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))
        )}
        
        {/* Right Side Alphabet Nav (Simulated) */}
        <div className="fixed right-1 top-40 bottom-20 w-6 flex flex-col items-center justify-center gap-0.5 pointer-events-none">
            {Object.keys(groupedExercises).sort().map(l => (
                <span key={l} className="text-[10px] text-blue-500/50 font-bold">{l}</span>
            ))}
        </div>
      </div>
    </div>
  );
};
