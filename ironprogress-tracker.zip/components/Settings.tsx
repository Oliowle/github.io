import React, { useState, useEffect } from 'react';
import { User, AppView } from '../types';
import { storage } from '../services/storage';
import { generatePDFReport } from '../services/reportService';
import { ArrowLeft, Moon, Sun, Download, Save, User as UserIcon, FileText } from 'lucide-react';

interface Props {
  user: User;
  onBack: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
  onUpdateUser: (u: User) => void;
}

export const Settings: React.FC<Props> = ({ user, onBack, isDarkMode, toggleTheme, onUpdateUser }) => {
  const [name, setName] = useState(user.name);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    setNotes(storage.getNotes());
  }, []);

  const handleSaveProfile = () => {
    const updated = { ...user, name };
    storage.updateUser(updated);
    onUpdateUser(updated);
    alert('Profil gespeichert.');
  };

  const handleSaveNotes = () => {
    storage.saveNotes(notes);
    alert('Notizen gespeichert.');
  };

  const handleExport = () => {
    generatePDFReport(user.name);
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center gap-4 mb-6">
        <button onClick={onBack} className="bg-slate-200 dark:bg-slate-800 p-2 rounded-full text-slate-600 dark:text-slate-400 hover:text-blue-500">
            <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Einstellungen</h2>
      </div>

      {/* Profile Section */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
            <UserIcon className="w-5 h-5 text-blue-500" /> Profil
        </h3>
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">Name</label>
                <input 
                    type="text" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-100 dark:bg-slate-700 border-none rounded-lg px-4 py-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                />
            </div>
            <button 
                onClick={handleSaveProfile}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 hover:bg-blue-700 transition-colors"
            >
                <Save className="w-4 h-4" /> Name speichern
            </button>
        </div>
      </div>

      {/* Appearance Section */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between">
         <div>
             <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                 {isDarkMode ? <Moon className="w-5 h-5 text-purple-500" /> : <Sun className="w-5 h-5 text-amber-500" />} 
                 Darstellung
             </h3>
             <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                 {isDarkMode ? 'Dunkelmodus aktiv' : 'Hellmodus aktiv'}
             </p>
         </div>
         <button 
            onClick={toggleTheme}
            className={`w-14 h-8 rounded-full p-1 transition-colors flex items-center ${isDarkMode ? 'bg-blue-600 justify-end' : 'bg-slate-300 justify-start'}`}
         >
             <div className="w-6 h-6 bg-white rounded-full shadow-md"></div>
         </button>
      </div>

      {/* Data Export */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
            <Download className="w-5 h-5 text-green-500" /> Daten Export
        </h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
            Erstelle einen detaillierten PDF-Bericht deiner Trainingshistorie für deinen Trainer.
        </p>
        <button 
            onClick={handleExport}
            className="w-full bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white px-4 py-3 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors"
        >
            <Download className="w-5 h-5" /> Bericht herunterladen (PDF)
        </button>
      </div>

      {/* Notes */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-500" /> Notizen
        </h3>
        <textarea 
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full h-32 bg-slate-100 dark:bg-slate-700 border-none rounded-lg p-4 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none resize-none mb-3"
            placeholder="Schreibe hier deine Ziele oder Anmerkungen..."
        />
        <button 
            onClick={handleSaveNotes}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 hover:bg-blue-700 transition-colors"
        >
            <Save className="w-4 h-4" /> Notizen speichern
        </button>
      </div>

    </div>
  );
};