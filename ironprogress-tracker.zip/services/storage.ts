import { BodyMeasurements, ProgressPhoto, User, WorkoutPlan, WorkoutSessionLog } from '../types';

const KEYS = {
  USER: 'ipt_user', // Current active session/user profile
  USERS_DB: 'ipt_users_db', // Database of all registered users
  PLANS: 'ipt_plans',
  SESSIONS: 'ipt_sessions',
  MEASUREMENTS: 'ipt_measurements',
  PHOTOS: 'ipt_photos',
  NOTES: 'ipt_notes',
};

export const storage = {
  // --- User / Profile Management ---
  getUser: (): User | null => {
    const data = localStorage.getItem(KEYS.USER);
    return data ? JSON.parse(data) : null;
  },
  
  setUser: (user: User) => {
      localStorage.setItem(KEYS.USER, JSON.stringify(user));
  },
  
  updateUser: (updatedUser: User) => {
    storage.setUser(updatedUser);
  },

  registerUser: (email: string, name: string, password: string): boolean => {
    const data = localStorage.getItem(KEYS.USERS_DB);
    const users: any[] = data ? JSON.parse(data) : [];

    if (users.some((u: any) => u.email === email)) {
        return false;
    }

    const newUser = {
        id: crypto.randomUUID(),
        email,
        name,
        password
    };
    users.push(newUser);
    localStorage.setItem(KEYS.USERS_DB, JSON.stringify(users));
    return true;
  },

  loginUser: (email: string, password: string): User | null => {
    const data = localStorage.getItem(KEYS.USERS_DB);
    const users: any[] = data ? JSON.parse(data) : [];
    
    const user = users.find((u: any) => u.email === email && u.password === password);
    if (user) {
        const { password: _, ...safeUser } = user;
        storage.setUser(safeUser);
        return safeUser as User;
    }
    return null;
  },

  logout: () => {
      localStorage.removeItem(KEYS.USER); 
  },

  // --- Data Management ---
  getPlans: (): WorkoutPlan[] => {
    const data = localStorage.getItem(KEYS.PLANS);
    return data ? JSON.parse(data) : [];
  },
  savePlan: (plan: WorkoutPlan) => {
    const plans = storage.getPlans();
    const existingIndex = plans.findIndex(p => p.id === plan.id);
    if (existingIndex >= 0) {
      plans[existingIndex] = plan;
    } else {
      plans.push(plan);
    }
    localStorage.setItem(KEYS.PLANS, JSON.stringify(plans));
  },
  deletePlan: (id: string) => {
    const plans = storage.getPlans().filter(p => p.id !== id);
    localStorage.setItem(KEYS.PLANS, JSON.stringify(plans));
  },

  getSessions: (): WorkoutSessionLog[] => {
    const data = localStorage.getItem(KEYS.SESSIONS);
    return data ? JSON.parse(data) : [];
  },
  saveSession: (session: WorkoutSessionLog) => {
    const sessions = storage.getSessions();
    sessions.push(session);
    localStorage.setItem(KEYS.SESSIONS, JSON.stringify(sessions));
  },
  getLastSessionForPlan: (planId: string): WorkoutSessionLog | undefined => {
    const sessions = storage.getSessions().filter(s => s.planId === planId);
    return sessions.sort((a, b) => b.date - a.date)[0];
  },
  getLastLogForExercise: (exerciseName: string): number | null => {
    // Find the most recent weight used for this exercise across all sessions
    const sessions = storage.getSessions().sort((a, b) => b.date - a.date);
    for (const s of sessions) {
      if (s.exercises[exerciseName] && s.exercises[exerciseName].length > 0) {
        // Return the max weight from the last session of this exercise
        return Math.max(...s.exercises[exerciseName].map(set => set.weight));
      }
    }
    return null;
  },

  getMeasurements: (): BodyMeasurements[] => {
    const data = localStorage.getItem(KEYS.MEASUREMENTS);
    return data ? JSON.parse(data) : [];
  },
  addMeasurement: (m: BodyMeasurements) => {
    const list = storage.getMeasurements();
    list.push(m);
    localStorage.setItem(KEYS.MEASUREMENTS, JSON.stringify(list));
  },

  getPhotos: (): ProgressPhoto[] => {
    const data = localStorage.getItem(KEYS.PHOTOS);
    return data ? JSON.parse(data) : [];
  },
  addPhoto: (p: ProgressPhoto) => {
    const list = storage.getPhotos();
    list.push(p);
    localStorage.setItem(KEYS.PHOTOS, JSON.stringify(list));
  },
  getLatestPhoto: (perspective: string): ProgressPhoto | undefined => {
     const photos = storage.getPhotos().filter(p => p.perspective === perspective);
     return photos.sort((a, b) => b.date - a.date)[0];
  },

  // --- Notes ---
  saveNotes: (notes: string) => {
      localStorage.setItem(KEYS.NOTES, notes);
  },
  getNotes: (): string => {
      return localStorage.getItem(KEYS.NOTES) || '';
  }
};