import { GoogleGenAI } from "@google/genai";
import { WorkoutPlan } from '../types';

/**
 * Helper to clean Markdown code blocks from AI response
 */
const cleanAndParseJSON = (text: string): any => {
  // Remove ```json and ``` wrappers if present
  let cleaned = text.replace(/```json/g, '').replace(/```/g, '');
  
  // Find the first '{' and the last '}' to isolate the JSON object
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  
  if (firstBrace !== -1 && lastBrace !== -1) {
    cleaned = cleaned.substring(firstBrace, lastBrace + 1);
  }

  try {
    return JSON.parse(cleaned);
  } catch (e) {
    console.error("JSON Parse Error on text:", cleaned);
    throw new Error("Die KI-Antwort war kein gültiges JSON.");
  }
};

export const parseWorkoutPlanImage = async (
  file: File,
  basePlanName: string
): Promise<WorkoutPlan[]> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key not found");

  const ai = new GoogleGenAI({ apiKey });

  // Convert File to Base64
  const base64Data = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = error => reject(error);
  });

  // Updated prompt to handle MULTIPLE plans (e.g. Tag 1, Tag 2) in one file
  const prompt = `
    Du bist ein Fitness-Experte. Analysiere dieses Dokument. Es enthält einen oder mehrere Trainingspläne (z.B. Tag 1, Tag 2, Tag A, Tag B).
    
    Deine Aufgabe:
    Extrahiere JEDEN Trainingstag als separaten Plan.
    
    Antworte AUSSCHLIESSLICH mit einem validen JSON-Objekt in folgendem Format:
    {
      "plans": [
        {
          "name": "Name des Tages (z.B. Tag 1 Push)",
          "warmup": "Der Aufwärmtext exakt wie im Dokument",
          "exercises": [
            {
              "name": "Übungsname",
              "equipment": "Gerät oder Ausführungsinfos",
              "sets": 3,
              "reps": "8-12",
              "notes": "Zusatzinfos"
            }
          ]
        }
      ]
    }

    WICHTIGE REGELN:
    1. Wenn das Dokument "Tag 1", "Tag 2" usw. enthält, erstelle für jeden Tag einen Eintrag im "plans" Array.
    2. Übernimm das Aufwärmen (Warmup) exakt so, wie es da steht.
    3. "sets" muss eine Zahl sein (Integer).
    4. "reps" ist ein String (z.B. "10-12" oder "Dropsatz").
  `;

  try {
    // Using generateContent without strict responseSchema for better flexibility with large PDFs
    // We rely on the prompt to enforce structure, which is often more robust for complex OCR tasks.
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          { inlineData: { mimeType: file.type, data: base64Data } },
          { text: prompt }
        ]
      },
      config: {
        // We request JSON MIME type but handle parsing manually to be safe
        responseMimeType: 'application/json', 
      }
    });

    if (!response.text) {
      throw new Error("Keine Antwort von Gemini erhalten.");
    }

    const data = cleanAndParseJSON(response.text);

    if (!data.plans || !Array.isArray(data.plans)) {
      console.error("Unexpected JSON structure:", data);
      throw new Error("Die KI konnte keine Liste von Plänen finden.");
    }

    // Map to our App's Type
    const parsedPlans: WorkoutPlan[] = data.plans.map((p: any, index: number) => ({
      id: crypto.randomUUID(),
      // If the AI didn't find a specific name, fall back to user input + index
      name: p.name || `${basePlanName} (Tag ${index + 1})`,
      warmup: p.warmup || "Kein spezielles Aufwärmen erkannt.",
      exercises: Array.isArray(p.exercises) ? p.exercises.map((e: any) => ({
        name: e.name || "Unbekannte Übung",
        equipment: e.equipment || "",
        sets: typeof e.sets === 'number' ? e.sets : 3,
        reps: String(e.reps || "10"),
        notes: e.notes || ""
      })) : [],
      createdAt: Date.now() + index // Slight offset to keep sort order
    }));

    return parsedPlans;

  } catch (error: any) {
    console.error("Gemini Service Error:", error);
    throw new Error(`Fehler bei der Analyse: ${error.message}`);
  }
};