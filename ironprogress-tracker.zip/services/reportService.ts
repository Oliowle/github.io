import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { storage } from './storage';

export const generatePDFReport = (userName: string) => {
  const doc = new jsPDF();
  const sessions = storage.getSessions().sort((a, b) => b.date - a.date);
  const measurements = storage.getMeasurements().sort((a, b) => b.date - a.date);
  
  // Title
  doc.setFontSize(22);
  doc.setTextColor(30, 41, 59); // Slate-800
  doc.text(`Trainingsbericht: ${userName}`, 14, 22);
  
  doc.setFontSize(10);
  doc.setTextColor(100, 116, 139); // Slate-500
  doc.text(`Erstellt am: ${new Date().toLocaleDateString('de-DE')}`, 14, 28);
  doc.setLineWidth(0.5);
  doc.setDrawColor(203, 213, 225); // Slate-300
  doc.line(14, 32, 196, 32);

  // --- Section 1: 3-Month Summary ---
  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42); // Slate-900
  doc.text('1. Zusammenfassung (Letzte 3 Monate)', 14, 45);
  
  const today = new Date();
  const threeMonthsAgo = new Date();
  threeMonthsAgo.setMonth(today.getMonth() - 3);

  const recentSessions = sessions.filter(s => new Date(s.date) >= threeMonthsAgo);
  const totalWorkouts = recentSessions.length;
  
  const distribution: {[key: string]: number} = {};
  recentSessions.forEach(s => {
      distribution[s.planName] = (distribution[s.planName] || 0) + 1;
  });

  const summaryData = Object.entries(distribution).map(([name, count]) => [name, count]);

  autoTable(doc, {
    startY: 50,
    head: [['Trainingsplan', 'Anzahl Einheiten']],
    body: summaryData,
    foot: [['Gesamt', totalWorkouts]],
    theme: 'striped',
    headStyles: { fillColor: [37, 99, 235] }, // Blue-600
    styles: { fontSize: 10, cellPadding: 3 },
  });

  // --- Section 2: Detailed Logs (Last Month) ---
  const oneMonthAgo = new Date();
  oneMonthAgo.setMonth(today.getMonth() - 1);
  const monthSessions = sessions.filter(s => new Date(s.date) >= oneMonthAgo);

  let finalY = (doc as any).lastAutoTable.finalY + 15;
  doc.setFontSize(14);
  doc.text('2. Detaillierte Einheiten (Letzter Monat)', 14, finalY);
  
  const detailData: any[] = [];
  
  monthSessions.forEach(session => {
      Object.entries(session.exercises).forEach(([exName, sets]) => {
          const maxWeight = Math.max(...sets.map(s => s.weight));
          const totalReps = sets.reduce((acc, s) => acc + s.reps, 0);
          
          detailData.push([
              new Date(session.date).toLocaleDateString('de-DE'),
              session.planName,
              exName,
              `${sets.length}`,
              `${maxWeight} kg`,
              `${totalReps}`
          ]);
      });
  });

  autoTable(doc, {
    startY: finalY + 5,
    head: [['Datum', 'Plan', 'Übung', 'Sätze', 'Max Gewicht', 'Gesamt Reps']],
    body: detailData,
    theme: 'grid',
    headStyles: { fillColor: [71, 85, 105] }, // Slate-600
    styles: { fontSize: 9, cellPadding: 2 },
    columnStyles: {
        0: { cellWidth: 25 },
        1: { cellWidth: 35 },
        2: { cellWidth: 60 }, // Exercise Name
    }
  });

  // --- Section 3: Body Measurements ---
  finalY = (doc as any).lastAutoTable.finalY + 15;
  
  // Check if we need a new page
  if (finalY > 250) {
      doc.addPage();
      finalY = 20;
  }

  doc.setFontSize(14);
  doc.text('3. Körperdaten & Messungen', 14, finalY);

  const bodyData = measurements.map(m => [
      new Date(m.date).toLocaleDateString('de-DE'),
      `${m.weight} kg`,
      `${m.chest} cm`,
      `${m.arm} cm`,
      `${m.waist} cm`,
      `${m.leg} cm`,
      `${m.calves} cm`
  ]);

  if (bodyData.length > 0) {
      autoTable(doc, {
        startY: finalY + 5,
        head: [['Datum', 'Gewicht', 'Brust', 'Arm', 'Taille', 'Bein', 'Waden']],
        body: bodyData,
        theme: 'striped',
        headStyles: { fillColor: [16, 185, 129] }, // Emerald-500 (Green)
        styles: { fontSize: 9, cellPadding: 3 }
      });
  } else {
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text('Keine Messdaten vorhanden.', 14, finalY + 10);
  }

  doc.save(`IronProgress_Bericht_${new Date().toISOString().split('T')[0]}.pdf`);
};