
export type BodyPart = 'Chest' | 'Back' | 'Legs' | 'Shoulders' | 'Arms' | 'Core' | 'Cardio' | 'Full Body';
export type Category = 'Barbell' | 'Dumbbell' | 'Machine' | 'Bodyweight' | 'Cable' | 'Other';

export interface ExerciseDef {
    id: string;
    name: string;
    bodyPart: BodyPart;
    category: Category;
}

export const EXERCISE_DATABASE: ExerciseDef[] = [
    // A
    { id: 'ab-wheel', name: 'Ab Wheel', bodyPart: 'Core', category: 'Bodyweight' },
    { id: 'aerobics', name: 'Aerobics', bodyPart: 'Cardio', category: 'Other' },
    { id: 'arnold-press-db', name: 'Arnold Press (Dumbbell)', bodyPart: 'Shoulders', category: 'Dumbbell' },
    { id: 'around-the-world', name: 'Around the World', bodyPart: 'Chest', category: 'Dumbbell' },
    
    // B
    { id: 'back-extension', name: 'Back Extension', bodyPart: 'Back', category: 'Bodyweight' },
    { id: 'back-extension-machine', name: 'Back Extension (Machine)', bodyPart: 'Back', category: 'Machine' },
    { id: 'ball-slams', name: 'Ball Slams', bodyPart: 'Full Body', category: 'Other' },
    { id: 'battle-ropes', name: 'Battle Ropes', bodyPart: 'Cardio', category: 'Other' },
    { id: 'bench-dip', name: 'Bench Dip', bodyPart: 'Arms', category: 'Bodyweight' },
    { id: 'bench-press-barbell', name: 'Bench Press (Barbell)', bodyPart: 'Chest', category: 'Barbell' },
    { id: 'bench-press-cable', name: 'Bench Press (Cable)', bodyPart: 'Chest', category: 'Cable' },
    { id: 'bench-press-db', name: 'Bench Press (Dumbbell)', bodyPart: 'Chest', category: 'Dumbbell' },
    { id: 'bench-press-smith', name: 'Bench Press (Smith Machine)', bodyPart: 'Chest', category: 'Machine' },
    { id: 'bench-press-close', name: 'Bench Press - Close Grip', bodyPart: 'Arms', category: 'Barbell' },
    { id: 'bench-press-incline-db', name: 'Incline Bench Press (Dumbbell)', bodyPart: 'Chest', category: 'Dumbbell' },
    { id: 'bench-press-incline-barbell', name: 'Incline Bench Press (Barbell)', bodyPart: 'Chest', category: 'Barbell' },
    { id: 'bent-over-row-bb', name: 'Bent Over Row (Barbell)', bodyPart: 'Back', category: 'Barbell' },
    { id: 'bent-over-row-db', name: 'Bent Over Row (Dumbbell)', bodyPart: 'Back', category: 'Dumbbell' },
    { id: 'bicep-curl-bb', name: 'Bicep Curl (Barbell)', bodyPart: 'Arms', category: 'Barbell' },
    { id: 'bicep-curl-db', name: 'Bicep Curl (Dumbbell)', bodyPart: 'Arms', category: 'Dumbbell' },
    { id: 'bicep-curl-machine', name: 'Bicep Curl (Machine)', bodyPart: 'Arms', category: 'Machine' },
    { id: 'box-jump', name: 'Box Jump', bodyPart: 'Legs', category: 'Bodyweight' },
    { id: 'burpees', name: 'Burpees', bodyPart: 'Full Body', category: 'Bodyweight' },

    // C
    { id: 'cable-crossover', name: 'Cable Crossover', bodyPart: 'Chest', category: 'Cable' },
    { id: 'cable-crunch', name: 'Cable Crunch', bodyPart: 'Core', category: 'Cable' },
    { id: 'calf-raise-seated', name: 'Calf Raise (Seated)', bodyPart: 'Legs', category: 'Machine' },
    { id: 'calf-raise-standing', name: 'Calf Raise (Standing)', bodyPart: 'Legs', category: 'Machine' },
    { id: 'chest-fly-machine', name: 'Chest Fly (Machine)', bodyPart: 'Chest', category: 'Machine' },
    { id: 'chin-up', name: 'Chin Up', bodyPart: 'Back', category: 'Bodyweight' },
    { id: 'clean-and-jerk', name: 'Clean and Jerk', bodyPart: 'Full Body', category: 'Barbell' },
    { id: 'crunch', name: 'Crunch', bodyPart: 'Core', category: 'Bodyweight' },

    // D
    { id: 'deadlift-barbell', name: 'Deadlift (Barbell)', bodyPart: 'Back', category: 'Barbell' },
    { id: 'deadlift-romanian', name: 'Romanian Deadlift', bodyPart: 'Legs', category: 'Barbell' },
    { id: 'dips', name: 'Dips', bodyPart: 'Arms', category: 'Bodyweight' },

    // F
    { id: 'face-pull', name: 'Face Pull', bodyPart: 'Shoulders', category: 'Cable' },
    { id: 'front-raise-db', name: 'Front Raise (Dumbbell)', bodyPart: 'Shoulders', category: 'Dumbbell' },
    { id: 'front-squat', name: 'Front Squat', bodyPart: 'Legs', category: 'Barbell' },

    // H
    { id: 'hammer-curl', name: 'Hammer Curl', bodyPart: 'Arms', category: 'Dumbbell' },
    { id: 'hanging-leg-raise', name: 'Hanging Leg Raise', bodyPart: 'Core', category: 'Bodyweight' },
    { id: 'hip-thrust', name: 'Hip Thrust', bodyPart: 'Legs', category: 'Barbell' },

    // L
    { id: 'lat-pulldown', name: 'Lat Pulldown', bodyPart: 'Back', category: 'Cable' },
    { id: 'lateral-raise-db', name: 'Lateral Raise (Dumbbell)', bodyPart: 'Shoulders', category: 'Dumbbell' },
    { id: 'lateral-raise-cable', name: 'Lateral Raise (Cable)', bodyPart: 'Shoulders', category: 'Cable' },
    { id: 'leg-curl', name: 'Leg Curl', bodyPart: 'Legs', category: 'Machine' },
    { id: 'leg-extension', name: 'Leg Extension', bodyPart: 'Legs', category: 'Machine' },
    { id: 'leg-press', name: 'Leg Press', bodyPart: 'Legs', category: 'Machine' },
    { id: 'lunge-db', name: 'Lunges (Dumbbell)', bodyPart: 'Legs', category: 'Dumbbell' },

    // M
    { id: 'mountain-climber', name: 'Mountain Climber', bodyPart: 'Core', category: 'Bodyweight' },

    // O
    { id: 'overhead-press-bb', name: 'Overhead Press (Barbell)', bodyPart: 'Shoulders', category: 'Barbell' },
    { id: 'overhead-press-db', name: 'Overhead Press (Dumbbell)', bodyPart: 'Shoulders', category: 'Dumbbell' },

    // P
    { id: 'plank', name: 'Plank', bodyPart: 'Core', category: 'Bodyweight' },
    { id: 'pull-up', name: 'Pull Up', bodyPart: 'Back', category: 'Bodyweight' },
    { id: 'push-up', name: 'Push Up', bodyPart: 'Chest', category: 'Bodyweight' },

    // R
    { id: 'russian-twist', name: 'Russian Twist', bodyPart: 'Core', category: 'Bodyweight' },

    // S
    { id: 'seated-row', name: 'Seated Cable Row', bodyPart: 'Back', category: 'Cable' },
    { id: 'shoulder-press-machine', name: 'Shoulder Press (Machine)', bodyPart: 'Shoulders', category: 'Machine' },
    { id: 'shrug-db', name: 'Shrug (Dumbbell)', bodyPart: 'Shoulders', category: 'Dumbbell' },
    { id: 'skullcrusher', name: 'Skullcrusher', bodyPart: 'Arms', category: 'Barbell' },
    { id: 'squat-barbell', name: 'Squat (Barbell)', bodyPart: 'Legs', category: 'Barbell' },
    { id: 'squat-goblet', name: 'Goblet Squat', bodyPart: 'Legs', category: 'Dumbbell' },

    // T
    { id: 't-bar-row', name: 'T-Bar Row', bodyPart: 'Back', category: 'Machine' },
    { id: 'tricep-extension-cable', name: 'Tricep Extension (Cable)', bodyPart: 'Arms', category: 'Cable' },
    { id: 'tricep-kickback', name: 'Tricep Kickback', bodyPart: 'Arms', category: 'Dumbbell' },
    { id: 'treadmill', name: 'Treadmill / Running', bodyPart: 'Cardio', category: 'Machine' },
];
