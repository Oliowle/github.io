import React, { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { PlanManager } from './components/PlanManager';
import { WorkoutSession } from './components/WorkoutSession';
import { BodyTracker } from './components/BodyTracker';
import { ProgressCharts } from './components/ProgressCharts';
import { Settings } from './components/Settings';
import { storage } from './services/storage';
import { User, AppView, WorkoutPlan } from './types';
import { LayoutGrid, Dumbbell, ClipboardList, User as UserIcon, BarChart2 } from 'lucide-react';

const App: React.FC = () => {
  // Initialize user immediately from storage or create default
  const [user, setUser] = useState<User>(() => {
    const saved = storage.getUser();
    return saved || { id: 'local-user', name: 'Sportler', email: 'local' };
  });

  const [currentView, setCurrentView] = useState<AppView>(AppView.DASHBOARD);
  const [selectedPlanForWorkout, setSelectedPlanForWorkout] = useState<WorkoutPlan | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    // Ensure the user is saved to storage if it was a fresh default
    if (!storage.getUser()) {
        storage.setUser(user);
    }

    // Initialize Theme
    if (document.documentElement.classList.contains('dark')) {
        setIsDarkMode(true);
    } else {
        setIsDarkMode(false);
    }
  }, []);

  const toggleTheme = () => {
      const newMode = !isDarkMode;
      setIsDarkMode(newMode);
      if (newMode) {
          document.documentElement.classList.add('dark');
      } else {
          document.documentElement.classList.remove('dark');
      }
  };

  const handleStartPlan = (plan: WorkoutPlan) => {
    setSelectedPlanForWorkout(plan);
    setCurrentView(AppView.WORKOUT);
  };

  const handleFinishWorkout = () => {
    setSelectedPlanForWorkout(null);
    setCurrentView(AppView.DASHBOARD);
  };

  // Nav Item Component
  const NavItem = ({ view, icon: Icon, label }: { view: AppView; icon: any; label: string }) => (
    <button 
      onClick={() => setCurrentView(view)}
      className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${currentView === view ? 'text-blue-500' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'}`}
    >
      <Icon className="w-6 h-6" />
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );

  return (
    <div className={`min-h-screen font-sans ${isDarkMode ? 'dark' : ''}`}>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 transition-colors duration-300">
        {/* Main Content Area */}
        <main className="p-4 max-w-2xl mx-auto min-h-screen">
            
            {currentView === AppView.DASHBOARD && (
                <Dashboard user={user} onChangeView={setCurrentView} onStartPlan={handleStartPlan} />
            )}
            
            {currentView === AppView.SETTINGS && (
                <Settings 
                    user={user} 
                    onBack={() => setCurrentView(AppView.DASHBOARD)} 
                    isDarkMode={isDarkMode}
                    toggleTheme={toggleTheme}
                    onUpdateUser={(u) => { setUser(u); storage.setUser(u); }}
                />
            )}

            {currentView === AppView.PLANS && <PlanManager />}
            {currentView === AppView.WORKOUT && <WorkoutSession initialPlan={selectedPlanForWorkout} onFinish={handleFinishWorkout} onCancel={handleFinishWorkout} />}
            {currentView === AppView.BODY && <BodyTracker />}
            {currentView === AppView.ANALYSIS && <ProgressCharts />}

        </main>

        {/* Bottom Navigation (Hidden during active workout) */}
        {currentView !== AppView.WORKOUT && (
            <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 h-16 z-40 shadow-lg">
            <div className="max-w-2xl mx-auto h-full flex justify-around items-center px-2">
                <NavItem view={AppView.DASHBOARD} icon={LayoutGrid} label="Home" />
                <NavItem view={AppView.PLANS} icon={ClipboardList} label="Pläne" />
                
                {/* Central Action Button */}
                <button 
                onClick={() => setCurrentView(AppView.WORKOUT)}
                className="flex items-center justify-center w-14 h-14 bg-blue-600 rounded-full shadow-lg shadow-blue-900/50 -mt-8 border-4 border-slate-50 dark:border-slate-900 hover:scale-105 transition-transform"
                >
                <Dumbbell className="w-6 h-6 text-white" />
                </button>

                <NavItem view={AppView.BODY} icon={UserIcon} label="Körper" />
                <NavItem view={AppView.ANALYSIS} icon={BarChart2} label="Analyse" />
            </div>
            </nav>
        )}
      </div>
    </div>
  );
};

export default App;