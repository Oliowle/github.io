export interface User {
  id: string;
  email: string;
  name: string;
}

export interface ExercisePlan {
  name: string;
  equipment: string;
  sets: number;
  reps: string;
  notes: string;
}

export interface WorkoutPlan {
  id: string;
  name: string; // e.g., "Tag A"
  warmup: string;
  exercises: ExercisePlan[];
  createdAt: number;
}

export interface WorkoutSetLog {
  setNumber: number;
  weight: number;
  reps: number; // Actual reps done
  timestamp: number;
}

export interface WorkoutSessionLog {
  id: string;
  planId: string;
  planName: string;
  date: number;
  exercises: {
    [exerciseName: string]: WorkoutSetLog[];
  };
}

export interface BodyMeasurements {
  date: number;
  weight: number;
  arm: number;
  chest: number;
  waist: number;
  hips: number;
  leg: number;
  calves: number;
}

export type PhotoPerspective = 'front' | 'side' | 'back' | 'biceps';

export interface ProgressPhoto {
  id: string;
  date: number;
  perspective: PhotoPerspective;
  imageData: string; // Base64
}

export enum AppView {
  LOGIN = 'LOGIN', // Kept for enum compatibility but unused
  DASHBOARD = 'DASHBOARD',
  PLANS = 'PLANS',
  WORKOUT = 'WORKOUT',
  BODY = 'BODY',
  ANALYSIS = 'ANALYSIS',
  SETTINGS = 'SETTINGS',
}